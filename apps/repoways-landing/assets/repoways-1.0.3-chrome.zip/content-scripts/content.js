(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function n(e){let n=e.replace(/\./g,`_`);return t.i18n.getMessage(n)||e}var r=`/* The "open with" menu's shadow-UI styles. Imported with \`?raw\` by
   entrypoints/content.ts (as MENU_STYLE) and dropped into the shadow root as a
   string: a stylesheet file next to an entrypoint would be scanned as a CSS
   entrypoint and emitted separately, and shadow DOM inherits nothing from the
   page anyway — only custom properties cross that boundary, which is exactly
   what the GitHub tokens below rely on.

   Those tokens are Primer's current naming (\`--fgColor-*\` / \`--bgColor-*\` /
   \`--borderColor-*\`, measured on github.com 2026-10-14: the old
   \`--color-btn-bg\` family is gone bar \`--shadow-resting-medium\`), so the menu
   follows the page's light/dark theme for free. The literals are GitHub's own
   light values. The panel block reads the same four tokens GitHub's own \`Code\`
   dropdown uses — \`--overlay-bgColor\` / \`--shadow-floating-small\` /
   \`--borderRadius-large\` / \`--control-transparent-bgColor-hover\` — and mind the
   word order in the first: it is \`--overlay-bgColor\`, **not**
   \`--bgColor-overlay\`, which resolves to nothing and would leave the panel
   unpainted.

   \`.rw-btn\` is different: its colours and metrics are copied off the real branch
   switcher at runtime (see DONOR_PROPS in content.ts), so the declarations below
   only apply when that control is absent — some repo layouts and narrow
   viewports render the row without it. They are the branch button's measured
   light-mode values, token-driven where a token exists (\`--bgColor-muted\` is
   #f6f8fa, \`--borderRadius-medium\` 6px, \`--control-medium-gap\` .5rem).

   The label colour is the one place the fallback used to drift: it read
   \`--fgColor-default\` (#1f2328), the page's own foreground, while every button
   on github.com paints \`--button-default-fgColor-rest\` (#25292e) — measured 2026-10-15,
   \`rgb(37, 41, 46)\` on the branch switcher and on "Go to file" alike. The two
   differ by 6/255 in light mode and resolve to the same #f0f6fc in dark, so the
   button token is both the correct one and the safe one to read. */
/* GitHub's page-wide reset, repeated here because \`box-sizing\` is not inherited
   across the shadow boundary. Without it every metric below lands outside the
   box — the button's copied padding + height, the panel's 8px inset, the rows'
   32px min-height (which is a content-box height, so it grows to 44px). */
*,
*::before,
*::after {
  box-sizing: border-box;
}
.rw {
  display: inline-flex;
  position: relative;
}
.rw-btn {
  align-items: center;
  background: var(--bgColor-muted, #f6f8fa);
  border: 0.8px solid var(--borderColor-default, #d1d9e0);
  border-radius: var(--borderRadius-medium, 6px);
  box-shadow: 0 1px 0 rgba(31, 35, 40, 0.04);
  color: var(--button-default-fgColor-rest, #25292e);
  cursor: pointer;
  display: inline-flex;
  font: inherit;
  font-size: 14px;
  font-weight: 500;
  gap: var(--control-medium-gap, 8px);
  justify-content: center;
  line-height: 21px;
  padding: 0 12px;
  white-space: nowrap;
}
.rw-btn:hover {
  background: var(--control-transparent-bgColor-hover, rgba(129, 139, 152, 0.1));
}
.rw-menu {
  background: var(--overlay-bgColor, #fff);
  border-radius: var(--borderRadius-large, 12px);
  /* GitHub's popovers carry no border — the hairline ring is the first layer of
     this shadow token. */
  box-shadow: var(--shadow-floating-small, 0 0 0 1px #d1d9e040, 0 6px 12px -3px #25292e0a, 0 6px 18px 0 #25292e1f);
  padding: 8px;
  position: fixed;
  /* Width follows the longest row instead of a fixed 400px — a row is a mark, a
     service name and a short description, so a wide panel spends most of itself
     on empty space. Measured in the harness with the icons in and all twelve
     rows: zh_CN lands at 238.93px and en at 285.34px, and in both locales the
     longest row is the same one — "Dependency Graph" + its description ("看依赖图"
     / "List dependencies"). The 2026-10-15 pass that shortened every description
     (dropping redundant qualifiers, "浏览器里读代码" → "读代码") took en down from
     300.7px and zh_CN down from 262.93px; the same day's removal of the
     Sourcegraph and Star History rows then moved neither, because neither was
     anywhere near the longest. A longer service name or description has to land
     within that, or the nowrap row overflows the panel instead of widening it.
     The floor is a guard for a very short locale, not what either of ours
     measures; the viewport clamp replaces the one the fixed width used to give. */
  max-width: min(320px, calc(100vw - 16px));
  /* min() rather than a plain 220px: \`min-width\` beats \`max-width\` in the box
     model, so a bare floor would push the panel off a viewport narrower than it
     (the \`show()\` clamp only moves it, it cannot shrink it). */
  min-width: min(220px, calc(100vw - 16px));
  width: max-content;
  z-index: 2147483640;
}
/* The panel fades in where GitHub's own dropdown does. Measured on github.com
   2026-10-16: the Code button's React overlay (\`.prc-AnchoredOverlay
   .prc-Overlay\`) runs \`prc-Overlay-overlay-appear\` — opacity 0 → 1 over 0.2s
   with Primer's standard \`cubic-bezier(0.33, 1, 0.68, 1)\` (the computed
   animation reads exactly \`0.2s cubic-bezier(0.33, 1, 0.68, 1)
   prc-Overlay-overlay-appear-…\`), and its keyframes carry **no transform**, so
   the panel neither scales nor slides — a screen recording of the real
   dropdown shows it holding its size and position while only the opacity ramps
   up. Cheap fidelity: the animation replays on every open with no JS, because
   \`hidden\` toggles \`display\` and an animation restarts when an element goes
   from \`display: none\` back to a rendered state. Primer wraps the equivalent
   rule in \`@media screen and (prefers-reduced-motion: no-preference)\` rather
   than posting it unconditionally, so the same guard is repeated here. */
@keyframes rw-menu-appear {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@media screen and (prefers-reduced-motion: no-preference) {
  .rw-menu {
    animation: 0.2s cubic-bezier(0.33, 1, 0.68, 1) rw-menu-appear;
  }
}
/* One ActionList row: 32px tall, 6px corner, and the highlight is a rounded
   block inset from the panel rather than a full-width band — which is also why
   there are no dividers between rows. GitHub separates groups, not items, and
   \`.rw-divider\` below is that separation. */
.rw-item {
  align-items: center;
  border-radius: var(--borderRadius-medium, 6px);
  color: var(--fgColor-default, #1f2328);
  display: flex;
  font: inherit;
  font-size: 14px;
  gap: 16px;
  justify-content: space-between;
  line-height: 20px;
  min-height: 32px;
  padding: 6px 8px;
  text-decoration: none;
}
.rw-item:hover {
  background: var(--control-transparent-bgColor-hover, rgba(129, 139, 152, 0.1));
}
/* The one divider the menu draws. GitHub separates *groups*, not rows, and it
   does that with an element of its own rather than with a border on the next
   row — Primer's \`ActionList.Divider\` is \`height: 1px; background:
   var(--borderColor-muted); margin-block: 7px 8px\` with **no inline inset**,
   because the 8px inset lives on the items there (\`margin-inline: 8px\`) instead
   of on the list. Ours is the mirror image — the panel carries the padding — so
   the negative inline margin below cancels exactly that 8px and the seam reaches
   both edges of the panel while the rows stay inset. Reading
   \`--borderColor-default\` rather than the \`-muted\` name that rule uses is
   deliberate: primer/primitives aliases \`borderColor.muted\` to
   \`borderColor.default\`, so the two resolve to the same pixel (#d1d9e0 / #3d444d)
   — and this way the seam cannot go lighter than the hairline GitHub actually
   paints if a page still publishes the older alpha'd \`-muted\` value. The token
   flips with the theme, so the seam tracks light/dark for free, and content.ts
   inserts the element only where the group changes, so the menu's first row is
   never preceded by one and there are exactly (groups - 1) of them. */
.rw-divider {
  background: var(--borderColor-default, #d1d9e0);
  height: 1px;
  /* 7px above / 8px below is Primer's own \`margin-block\` (it writes the top as
     \`calc(8px - 1px)\`), so the seam reads as a seam rather than as the edge of
     the row under it. */
  margin: 7px -8px 8px;
}
.rw-desc {
  color: var(--fgColor-muted, #59636e);
  font-size: 12px;
  white-space: nowrap;
}
/* The mark is part of the title, not a decoration beside it: icon and name form
   one group so the 16px gap that separates the two halves of the row sits
   outside them (GitHub's own ActionList puts 8px between icon and label). */
.rw-lead {
  align-items: center;
  display: inline-flex;
  gap: 8px;
  min-width: 0;
}
/* \`flex: none\` — a brand mark that squashes to pay for a long service name is
   worse than a row that wraps. The SVG itself has no width/height attributes
   (those are the coordinate space's, not the box's), so it is sized here. */
.rw-icon {
  flex: none;
  height: 16px;
  width: 16px;
}
`,i={gitdiagram:{viewBox:`0 0 16 16`,body:`<image href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAACgElEQVRYhcXXv49MURQH8M8bYyxhG0Gh2LURjahEISGREBGFIJFIFErVZrVIbBR+VYIEf4IGiYpCNBJRWBGFQiuREBXZXWt2n+LeZ543b2beMxu+yU3enHvPud9z7j3nnuE/IykT3t75ub6lNAWTM5tqqTWKgm2je4uiFtb0GCMyJ5KEJKlNvisCOQOrcBrHsBppCflPmMIivmM+m5x8vbESgWafuSO4KXjZCx+xEocwgctYyBypQqLrCHLYM2BzguepEKFzOC8cmYzEMARWDtTuII3ra5PoR+Bv0KpLYrkJ1CbR7xJWRao7mzIScBU/einXITCPpfjdEC7oiji+4lu0l+bWTGEWN/BzGAIvcUknz0cwjV1CtjzEAbmQRyRRJ6E8NasSeIOnBdkR7BZyfz3e6i5WWYqO4UOZ4aoEyt6MTLYFtwRPiwQI6XkHZ4chUGY4L0sET3uheDS/UTUNx7FVeB9Wxe/xirp9UTUCB/EEJ+Pv+8K5/jMCTWzWCfPmGrrLQgDaOgWlXTJfVicGouodWMQ9vIvjXpRleIWjOBzHUaF2DESVCPwU+oJpzEXZtFDh9glOPNC7TgxN4D2uxw0zzDYk00vSrCVr0/UolPabRVQ5ggmcKBhsLElPCTX+Bo6X7FhWO7pQJQJrhQhoL7TvLi02tFY3zkTZurhmHDNiOyYUnvHlIiBudK3Zao4Knl3IbQ778VwnO5qo1J/XScNRXInfxaPL6kRt9CNQ9n7/bQdV2gsMMvhCrs8fAvPRVin6ReCx0NH0+mMyCIlQNx5FWz0X/YENIztc3P4sL2oNINoPbZ3MMPl6TKeWBXQZ/jL/rihayBsZDnODl/xr/AJ7r4wjR/bsmAAAAABJRU5ErkJggg==" width="16" height="16"/>`},depgraph:{viewBox:`0 0 16 16`,body:`<path fill="currentColor" d="M1.5 1.75V13.5h13.75a.75.75 0 0 1 0 1.5H.75a.75.75 0 0 1-.75-.75V1.75a.75.75 0 0 1 1.5 0Zm14.28 2.53-5.25 5.25a.75.75 0 0 1-1.06 0L7 7.06 4.28 9.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.25-3.25a.75.75 0 0 1 1.06 0L10 7.94l4.72-4.72a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Z"/>`},deepwiki:{viewBox:`0 0 16 16`,body:`<image href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAPoAAAD6AG1e1JrAAADtklEQVRo3u2YzWtcVRTAf/feN+/NTDJJqNhkQkzShUSiq6ya4kcEdWGFFq1CKRJCbEWx0vq1sIsoqdK6UKm0VFFEQUGFNmksVqILbcGPtFpLqAsjZJWkKZnMpEySmXn3XhftPDq4EJxJJoF3/oDL+b1zfuee+0Rdw62WdRySdR4hQAgQAoQAIUAIEAKEAGsFQAiBEGJ9AjiOwhhLLpdHKYWUcn0ACCFQSpFOZ3AcSXt7G5l0mkKhgFJqbQMIIdBas7CwwP09PZweGeK38z9x+PAhGurrubZwbcVbSvzfB40QAmMMnufx1qE36O19Eikl1lqEEExNTbNv/4ucGjlNLBbDGLO2KiCEIJ/P03pbC7t27URKidYagHw+T3Nzkh07Hg0Sl1KilEIpVdGqOOUeYC34vo/rukgpAycACvkCxhiUUiwuLpLP58BCNBbD9Ty071dfYqkkjuNgrS2BAujq6iKZbGLu6lWSySbeO/IugwdfJx6LkZ6fr74DhUKBxsZGvh/9hk2b2kvapejC+Pg45y/8zkMPPkBzcxKAiYm/GTz4JkPDI9UDKIHYuJGXX3qBvr5eolGPy5f/5KOPP6GttZVnn9kTVMgYA0KgbtwRjz+xkxMnh6mvrw/8WVUHrLVEIhGuzM7y3N59fPHlV3R2dnLi5BCzV2axZpmaeIz+/j583ycSiQCgtUYpRTxegzG2uhIDuK7L0tISf01MkMvlSc2liMaiLGWXSc2nivUqqVzxAyCqOIWEEPi+jxCCp/fs5sCrr9DS0sLwqa95/4MPaW9rZfdT/QAoJTHGBG4AGGPKzb88ibXW1NUl+PyzT7nv3nuCSSSECBKdS6WYnJzkrjs78bwoANlslqPHjvP2O0fIZrMopUqm2KpUoChwsqmJ7s2bsdZirUVKie/7OI7D9MwM27Y/xqVL42zp7mZg4ACZdIaB1wa5+MdFamsTZSVfEQe0Mfh+AdeN/KvHf/zhLGNjF2hoaODsuXNsfWQ7xmi0r9mw4Ra01mUlXxEAJRWOEwmkLLZWcWVwXQ8hBIlE4sY94SC86+5UdRey1uI4EaZnZhgbGyvpfdd1Mcbw8y+/Yu11cW+e85Vc7MoEUGQyGR7euo29z+9namoaIQRnznzLlrt7OHrsOPF4PEi46MmaWKdv7ndrLQvpNLd3dHBHRwej342itaGmpmbF1uiKARQvKcdRLC8vk8vlqK2tDd4LKx1OZY6xwUrteV5FpssqA1RezvC/UAgQAoQAIUAIEAKEACHAf8c/HTGd6POwrvoAAAAASUVORK5CYII=" width="16" height="16"/>`},zread:{viewBox:`0 0 16 16`,body:`<image href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAHqElEQVR4nO2dXWgUVxiGV435I1RKb0I0rcWkBAulUKU3UgoBQ279iz9BBeMvRNj2sjelUOm9FDVFhVIotdSAJoWWQq3eFKpLoLXQ0ESNmsSIwVbyUzWefu/EgWWdSTbZ+eYwc94HXtC92JzZ85wz386eM5PJFIkx5iVJh+RryW+SUcl/hthmSjIs+VXypaRdUl1svxbT8e9JfpRM2ztGskAmJBckb5fS8TWSryQzVg+FlMJTyXFJ5UI7/33JLbttJxFyXfJmsZ3fJnlkucEkeh5INszX+W9J/rXcUKLHmKQ+rPNflgxabiDRJyepChLgG9stI7HxaWHnv2NmK0biBo8lr+cL8L3tFpHY+Tz/3M8reu4xKamBAJ22W0Ks0QoBemy3gljjMwjwp+1WEGv8AgEe2m4FscYIBHhsuxXEGlMZ2y0gdqEAjkMBHIcCOA4FcBwK4DjqAkxPT5tcLmfOnj1rTp06VXLOnDljrl27ZiYnJ7WbXhQzMzPmzp07pru7O5Lj6+rqMj09Peb+/fvm2bNn6u1XFeDu3btmz549pqamxixZsiSyVFdXm507d5obN27E8iGFAblPnz5tGhoazLJlyyI7PrxXU1OTuXjxoieYJmoC4MPZvXu3Wbp0qcGPjlEHHxLkevjQ3oXM3t5es2LFCpXjQ+rr601fX5/qMagJgGkfI1/rw0Hq6urM5cuXrcwCU1NTprW1VfX4IHk2m/UGkxZqAuBcjelM8wOqqqrypmDtaTIInKMxTWseH9LS0mLGxsbUjkNNABQ02gJUVFSYkydPmqdP41/NNjo6ahobG9UFaG5u9v6WFhRgkaBTUPxRgBAoAAWgABSAAlAACkABKAAFoAAUgAJQAApAASgABaAAFIACUAAKQAEoAAWgABSAAqRSAKwCjmtFkA0BBgYGzOrVq9UF2LhxYzJXBGHpNlbvan44tbW15tKlS7GvCRwaGjKbN282y5cvVz0+LKjt7OxM5ppALJrctWuXt7BR48MpKyvz3n98fFzrEF4AomEPwJYtW9Q7H1m1apW5evWq6jGp7gvAuv29e/ealStXetM1ztmlBu+DkY/O7+/vj2304+9g2t+2bZspLy9/obMgehTHV1lZ6S01X79+vTl37pz66U1VAHxoWLd/5coV71yNgq3U4H0w7WPkxzn1Y+Tv2LHD66TCzsdr7e3t5sSJEyUfH4rn8+fPm5s3b5onT56oH1csewPRUVi6DZujSNzn/MHBQW/ax+gMKkQPHz5shoeHIzu+OJe5c3PoPIyMjJhNmzYF1jI4FXR0dKh+TdOGAoSAWQY1zNatWwPP+SgC9+3b520QSTIUIAB0/u3bt0MLPkz7Bw4cMPfu3bPd1JKhAAXMV+3j2saRI0cSPe3nQwEKwJb27du3h1b7Bw8e9OqCtEAB8kC1jyt8YdX+oUOHPEHSBAV4jl/tB93PAKcCFHxpOOcX4rwAOOdj5Le1tQVO+6j29+/fr/qDjE2cFgCdjx92UPAFdT4KPlT7aSn4gnBaAFT7GPlzVftpKviCcFaAYqp9XN61eROqOHBSAIz8sGofr6HaR+e7gHMCYOSj84OqfYx8VPtpLfiCcEYA/wofpv2gkY86AAWfS50PnBDAr/bDvur51X7aC74gnBAA3/Pnu7bvyjm/kNQLgFEdNvL9ad+Faj+MVAuAkY/Lu2Ff9Vyd9vNJpQAYzXNV+ygCXav2w0idAPNV+xj5+J7Pzp8lVQLkr+QJq/b9K3xkllQJgDV8rPYXRmoEQDE31wJOv+BztdoPIxUC+NV+UOfjNfyen+afdEsh0QLk79ULWrePZVys9ucmsQL41T62a81V7adxGVeUJFYAjPz5qv20LeDUIJEC4IcdTPthmzZcWMkTFbEIgHsFYAsVCrFS4y/mCNqf71f7LPiKR1UA3NkCD0HE07XwgCU8Ywf31SkluC1LUOeneem2JmoCYIsznhym+Vy9/Gkfu3STvlHTBmoC4JLsmjVr1DsfRSD253PaXxxqAuBZulr3B/KD98edOXh5d/Ek/j6BuC2LjdvEpYXEC2DrRpFpgQI4DgVwHArgOBTAcSiA41AAx6EAjkMBHIcCOA4FcBwK4DgUwHEogONQAMehAI6jJkBXV5e6ANgQQgFKQ02A3t5e9SVhWHCKByzF+YydtKEmAFborl27VlWAdevWeVvCyeJREwB797AnAA8/jHomwG1f8L54rl4cj1ZLM6obQzA19/X1mWw2a1paWrwHIZcaPEv36NGjJpfL8dwfAbFsDcMOIWzRjmJrGN5H81m6rpHIzaEkOiiA41AAx6EAjkMBHIcCOA4E4Hcqd5mAAOO2W0GsMQQBfrfdCmKNnyBAt+1WEGt8DAE6bLeCWKMZAtRIJm23hMTOP5LKDJB/fGu7NSR2jmV85D8Nkse2W0RiA1/9azP5yAtf2G4ViY0PM4WY2Vrguu2WEXV+MP65P0CCVyW8uX56uSV5JbDz8yR4V/LAckNJ9ODe+Y1zdn6eBG9I/rDcYBIdP0vqiur8PAkqJZ9IuPIyuWDJdFZStqDOLxChSXLc8GJRksBFnmOS1xbd8QEiVEuaJR9JLkj+lkzYO0bynEeSvyTfST6QbJCUF9uv/wOTWpVBZPGvfgAAAABJRU5ErkJggg==" width="16" height="16"/>`},gitreverse:{viewBox:`0 0 100 100`,body:`<g transform="translate(50 50) scale(1.12) translate(-690 -377.36218)"> <ellipse cx="690" cy="377.36218" rx="36" ry="23" transform="rotate(-52 690 377.36218)" fill="#d31611" stroke="#b0120e" stroke-width="1.1"/> <path fill="#fff" stroke="#141414" stroke-width="0.65" stroke-linejoin="round" d="m 690,361.11217 2.5,2.5 -10,10 c -2.5,2.5 -2.5,7.5 0,10 l 5,-5 10,-10 2.5,2.5 0,-10 z"/> <path fill="#fff" stroke="#141414" stroke-width="0.65" stroke-linejoin="round" d="m 690,393.61217 -2.5,-2.5 10,-10 c 2.5,-2.5 2.5,-7.5 0,-10 l -5,5 -10,10 -2.5,-2.5 0,10 z"/> </g>`},mcp:{viewBox:`0 0 16 16`,body:`<image href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAHe0lEQVR4AZxWeXBVVxn/fefem5ewtFoIFFswpUmsOrUutaNOXaZ0QxlB7KKlYElIpxRwgAJlEZJAI7SUTbYCYUuIiUhLO8w4zPQPlf+cqTpuzEgzVCt2IC+UpSRvufeer7+T8LLQBAJvvt8751vut93vnPcMbuzjF09Pfre0PPlmSXmy8a5nTt9NNzfk60Yeyiue0foTMXhLgR8y8JOx5x0tqUh+n3uPuC667gQYfLyovsooNxE5GgUrm4tnJL+dEwx0vZ4E/OKysw8z+B46H0FcQfpZUdSVlrfeR8WA/Q7UMCiZkXxcxDbQ+aeJ/uh2hb5eWtbyCA0G9DoGlMCd5S3jWN16Oh1G5IixkISiSVW3Ufg3IiZuU5Gt7JbrBNmr07US8NnScQZSx4Eb2cNVCtD60Oo9mUQwK/ClhoP4PYWU0aaFKDJiG0srWr/OvSH6pasp/ZIZrZxyPcCnhxM5audmSxi3PZfnmW8kMmFdFOsbno2rIPJ7VTxL/UcKjFGrvymuOPMQ+X7j9KsoKW/5FlQ301HPysmiriAbr/T9wRMUuh8CHj+5j69itlE7/+kxW48y4B8JR0VizfbPlSW/6pi+0FcCHoN/B5BGAKOIHKUYpDaM/aXtef5kUamnwrDiDRb6A+5jJvRQZWVlpCL/IJ+jIis4WNrP6bgyAVNSkRwPiGt77+DAtjY/nJfnxRMF+jKAPFHdYvxwjQfzFfIikGR1dTWbYpvJswv6IVdHRUzu1yUzzo4jY4gu6sUwy3thsZ3a24kc8VkcaPPCysFxMImMm3jeA7I6a9uqEfnPUlZN44yFbq+qqrI1D/+hbsrorY/YwH4BKq9TZ4mxULujpKLlS9x3US4Bj2f3fjo6RM1tRI447dgVWv/FIXHwFEurpSJmi18+PO/0St8bMpP7RZRliJWx6LHSstZpy44+0NTwv+d3eqF/t0SYC8DNBRcUwcqh4rKz3wTQEdt9meKKMw/S0X4KuysXpBV4LUjogjwveoz7l6BI8PhtUz/aNGn9yCUCrOAzXLDA99Dgw1umorsgOhmQqSyoEXn2HjFSDSAkHI3lhVZXUtb6ABlj7nrm9BfFmp1k7iC6yUpT+mL6F1HG/JjBt1JRyA6sOzyvZYVkvZkiWE5ZIIoFbPeuKMZcqD6Hjo8sod51c5hamdh+PvVPQD5A9+dOEa0trjj7eWM9bxPlo4lOko7KazMJ/4WCm/KnsQoXPOuCpy6kKydvHDmHzufROE1UZa0eYbt/yT0TwDnazQljy4tLA8rYWLTdkh+w0+qT7yIWNcZY+6o7Rj2nHWLlr7DRskQ2fILWq4gCoj6CXVcwNH8Jj91y8swBc8NYDwS+WQrICwDOCWQhk6zP8+UlQB4VIMm1KZVnvgZgJNGLmMQowxQ3UxoRHcR3+GUjwZtkXOXD6eSCFyaW+9ZMg2Ax5R7XhU+N3ron8MCqdSY4GJSteGP+6aaCm/N3McnpUGRiwQRrw/dEzWra9OoAeXZVN5l2L7uPQZyBm3jKUcAkuqaUjt9Om3SggolU+hBd4xscaTg1aw0g86FwZ31OBPvWpA0jt5D/KYD3IOYJC3sKxt9Mf+43geIuuqQiVWHU1mg+2PmZdps260SwluqY6EWq0i5ekGCSg6jgD595nwNXCYU7XudFZNHheWf2+mqqaTMFwHkLnS1ZPe6p2UsZTwR8ynMUiqJqUCba/J99d6Q5HEBzw7CLJ2oLq2jshil3XC4/oPeLpwyEv1CgAt3H1f3gKINXt19MHfzR+ltfo6yCyKqaCWLjP3PkdtOf+1/QHVyQZgcXnthTuP7v9be20b7zMnAbBz+h7IJu4N5dLFw6aKyJ7RRBXAORbXTKKxZHqJlu4/Bg/tDEWjr9Gfn/Ek/7UXBCPH8DZe6c05zSTmoXlVWpC5ldnWznd0cHOrfA8W0jLsWev5qluT8f7vp0KmHVK2LrTSzIREusjZ7UtJmqYo4Z468Xkek0auO5nh2JfScOMnv5eh6nrLtyIFRgeX42+tWp347OzRpNgF4JOMnJnbdcaK4dvgyQNQCyhKMRIliXCryTYrwGybdvi9qTdMp3rilr7KMmm/8nT417FRP4QEDkKKWKF5t3F27ItT2ncOsnEnBCB03LK1zdJZVLQiAoBORBAG6qXYX/ZyfK4zDveByk1wnA/wbUdlNKVGva/dDdtN3SHrt+E3CDyVbX8Cbs+Tp6PMqt4nfZwD8WmIj/DcQdv56Vc5h1aX5oN7mTRus+qd8EnLVLonn3iKWsYi35noNJtoOGDpFsyBnhXY/czDhFO1/P4nd3j9jUV9udQQ5XTSBnFPn+Gra/143ZoROMj9L4+cbH3qliQHeZXaQ8I5CaQdm437bTposGlIAbTGOxikls5JM9K72ZJ2bJ3EP3Vln+qLFTnBtdzLth47Uqp58OGlACzvLfewo/ere2cBEneiMTSTvZZQxmEgv9KJq1Y+q/XnFtv/KoXbbrcxlwArmns4mghvsdRM9OxAoJp+8vcieDqoHTdSfw/vZPnePrWKHASuG9T5xR1edDe6njbr8y9LX4jwEAAP//FLH1WgAAAAZJREFUAwBWlv/HN75VMwAAAABJRU5ErkJggg==" width="16" height="16"/>`},gitingest:{viewBox:`0 0 64 64`,body:`<path fill="#d4e9ff" d="M52,35V16L41,4H14.42A2.42,2.42,0,0,0,12,6.42V35H8V49h4v8.58A2.42,2.42,0,0,0,14.42,60H49.58A2.42,2.42,0,0,0,52,57.58V49h4V35Z"/> <polygon fill="#f1f8ff" points="52 16 41 16 41 4 52 16"/> <rect fill="#b7daff" x="12" y="49" width="40" height="4"/> <path d="M19.76,46.06a.91.91,0,0,1-.63-.23.83.83,0,0,1-.26-.66.85.85,0,0,1,.25-.62.83.83,0,0,1,.62-.26.87.87,0,0,1,.63.26.83.83,0,0,1,.26.62.84.84,0,0,1-.26.65A.88.88,0,0,1,19.76,46.06Z" fill="currentColor"/> <path d="M24.27,38.24v6.25H27.8a.93.93,0,0,1,.65.21.67.67,0,0,1,.23.52.65.65,0,0,1-.22.51,1,1,0,0,1-.65.2H23.6a.91.91,0,0,1-1.07-1.07V38.24a1.15,1.15,0,0,1,.24-.79.8.8,0,0,1,.62-.26.83.83,0,0,1,.64.26A1.13,1.13,0,0,1,24.27,38.24Z" fill="currentColor"/> <path d="M31.52,38.24v6.25H35a.93.93,0,0,1,.65.21.67.67,0,0,1,.23.52.65.65,0,0,1-.22.51,1,1,0,0,1-.65.2h-4.2a.91.91,0,0,1-1.07-1.07V38.24a1.15,1.15,0,0,1,.24-.79.8.8,0,0,1,.62-.26.83.83,0,0,1,.64.26A1.13,1.13,0,0,1,31.52,38.24Z" fill="currentColor"/> <path d="M40,44.62l-1.38-5.47v5.93a1.08,1.08,0,0,1-.22.74.81.81,0,0,1-1.16,0,1.07,1.07,0,0,1-.22-.74v-6.8a.85.85,0,0,1,.29-.76,1.4,1.4,0,0,1,.79-.2h.54a2.06,2.06,0,0,1,.71.09.59.59,0,0,1,.33.32,4.91,4.91,0,0,1,.24.74l1.25,4.71,1.25-4.71a4.91,4.91,0,0,1,.24-.74.59.59,0,0,1,.33-.32,2.06,2.06,0,0,1,.71-.09h.54a1.4,1.4,0,0,1,.79.2.85.85,0,0,1,.29.76v6.8a1.08,1.08,0,0,1-.22.74.75.75,0,0,1-.59.25.73.73,0,0,1-.57-.25,1.07,1.07,0,0,1-.22-.74V39.15L42.3,44.62c-.09.36-.16.62-.22.78a1.08,1.08,0,0,1-.31.45.91.91,0,0,1-.63.21.92.92,0,0,1-.84-.47,1.92,1.92,0,0,1-.18-.45Z" fill="currentColor"/> <path d="M57,35a1,1,0,0,0-1-1H53V16s0,0,0-.06a1,1,0,0,0,0-.21s0-.05,0-.07l0,0a1,1,0,0,0-.18-.29l-11-12a1,1,0,0,0-.29-.21l0,0-.06,0A1,1,0,0,0,41.11,3H14.42A3.42,3.42,0,0,0,11,6.42V34H8a1,1,0,0,0-1,1V49s0,0,0,.07a1.08,1.08,0,0,0,.34.68l0,.05L11,52.5v5.08A3.42,3.42,0,0,0,14.42,61H49.58A3.42,3.42,0,0,0,53,57.58V52.5l3.6-2.7,0-.05a1.08,1.08,0,0,0,.34-.68s0,0,0-.07ZM21,34V5H40V16a1,1,0,0,0,1,1H51V34ZM42,6.57,49.73,15H42ZM13,6.42A1.42,1.42,0,0,1,14.42,5H19V34H13ZM9,36H55V48H9Zm4,21.58V50h6v9H14.42A1.42,1.42,0,0,1,13,57.58ZM49.58,59H21V50H51v7.58A1.42,1.42,0,0,1,49.58,59Z" fill="currentColor"/>`},github1s:{viewBox:`0 0 400 400`,body:`<path fill="light-dark(#13227a,#0a84ff)" d="M35.587 25.574 C 26.887 34.274,22.366 85.319,28.408 106.640 C 29.808 111.581,30.362 115.990,29.639 116.436 C 22.375 120.926,6.586 153.361,2.311 172.577 C -1.702 190.614,-0.380 242.019,4.623 262.483 C 23.337 339.024,75.772 372.234,183.814 375.971 C 333.315 381.142,400.042 329.514,399.989 208.709 C 399.973 171.788,393.448 148.895,375.953 124.378 L 369.021 114.663 371.179 105.378 C 378.038 75.873,372.074 26.678,361.310 23.977 C 349.211 20.940,315.376 33.668,289.736 50.901 L 277.128 59.375 269.292 57.047 C 230.073 45.401,175.046 45.086,133.396 56.269 L 122.262 59.259 109.633 50.951 C 77.787 29.999,43.062 18.098,35.587 25.574 M199.219 174.024 C 215.547 173.970,243.672 173.640,261.719 173.291 C 297.764 172.594,302.347 173.496,314.439 183.671 C 360.164 222.146,353.423 307.996,302.675 333.490 C 257.998 355.934,129.596 354.142,90.730 330.533 C 37.291 298.070,45.173 192.813,102.426 174.343 C 108.963 172.234,114.738 172.025,139.844 172.986 C 156.172 173.611,182.891 174.078,199.219 174.024 M115.787 201.123 C 100.709 208.550,93.908 238.122,102.705 258.007 C 117.257 290.906,150.790 276.028,150.686 236.719 C 150.615 210.124,133.322 192.485,115.787 201.123 M265.858 201.088 C 262.979 202.507,258.887 206.290,256.767 209.495 C 233.925 244.011,263.236 295.935,289.886 268.166 C 314.409 242.614,294.482 186.985,265.858 201.088 M176.563 301.563 C 164.758 313.367,192.597 331.661,210.156 323.639 C 224.183 317.230,229.788 307.913,223.438 301.563 C 219.132 297.257,215.495 297.640,208.594 303.125 C 205.350 305.703,201.482 307.813,200.000 307.813 C 198.518 307.813,194.650 305.703,191.406 303.125 C 184.505 297.640,180.868 297.257,176.563 301.563"></path>`},githubdev:{viewBox:`0 0 16 16`,body:`<image href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABtUlEQVR42pXT32oTQRQG8O+m976BG9v0Oo/QR/AN9FIwTSNp2pDY7jYVK1Fj7hUXrSiKZTdNSlISWBG8aWzGpA1eziNMNuv9J9nF7awUjAd+DAxzzhzmD7BolL3MkvlVrbZ/2YajDPxX7PbvoNJX2Oxy9TgIpY8DL+2ozAI79zdQ7jFU6DDdDHQqWvRCXN9SqWeidMrYgxOmnSABqP800ZgQT8fVRPLWqYntLmNbXSLf9laOAuqA+kSifsnIRIbdFDo2ih3+xZrXXfk8oy5q//mlxLMLhmojhWKPyLeIzROi0FYotNb+NLb8aUZdNHsgDNTGErUxY+UvxLrrIe8kzmf544y6aHa+KNeSqA6IJ+MrBxciLK7FrQ8z6qLkjaZErkncd4mH34jHI53EvrgdF3jvUwfkXIl1l6GcK3DPMbAvGnj0gwnVkTkvkHrnUwdkHQtZh8geNRLXuCcsVAVje4KoDL3Uoc/UW5/heOjHZ3Dj2odkCQvWkLHSgMYbP+HfT9k8z8McErtDYntAw54mLPaZdr7fxc65QvGMxutpxJ56hq3WFv+R5bPMUkXIm6+mnvHyKvE3G1B3VgmyBAgAAAAASUVORK5CYII=" width="16" height="16"/>`},codespaces:{viewBox:`0 0 16 16`,body:`<path fill="currentColor" d="M0 11.25c0-.966.784-1.75 1.75-1.75h12.5c.966 0 1.75.784 1.75 1.75v3A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25Zm2-9.5C2 .784 2.784 0 3.75 0h8.5C13.216 0 14 .784 14 1.75v5a1.75 1.75 0 0 1-1.75 1.75h-8.5A1.75 1.75 0 0 1 2 6.75Zm1.75-.25a.25.25 0 0 0-.25.25v5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-5a.25.25 0 0 0-.25-.25Zm-2 9.5a.25.25 0 0 0-.25.25v3c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25v-3a.25.25 0 0 0-.25-.25Z"/>`},stackblitz:{viewBox:`0 0 16 16`,body:`<rect width="16" height="16" rx="2" fill="#1389fd"/><path d="M7.398 9.091h-3.58L10.364 2 8.602 6.909h3.58L5.636 14l1.762-4.909Z" fill="#fff"/>`},ossinsight:{viewBox:`0 0 16 16`,body:`<image href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAGXUlEQVR42r1WC0xTVxhuFQi0gC9oQVBE0Bl1DwWjDAfFWkTNjG6TbT7IzIhbHCBsxk03X3OKLiKii/gYiM86dQlqlNBFZbg4AYXZIVheAgWxYivUtvTe23u+7ZbhgNKKJniSL/fce8+5/3f/738cHu8lBgAOg9ra2vjclfcqBwA+y7KhhJA/CSFahmHyCgoKJi1dupT/SgiwLDsEgMZoNFKFhYXVhBBiNBrrS0tL350yZcrgATVO0/QQQshplmXZ+Ph4eUVFxbmSkpIqAIRlWWrfvn2LRSIRf8BcTwjZAYAFAKVSqaqqqrqclZV1nCPAQS6X5w4bNkw4YAQYhtnznzG0tbUZHz58WEVRVAd3z0mRkpJyzMXFRThgEhQWFo5Vq9W3Wltbn2i1Wj0nhUajaW9qatJlZGRcd3Nzm8fj8QYuK/z9/flisVg8dOjQ8JSUlFi9Xm/w8fFZ5eHhEeHp6TmOx+M5vZJM0Ov1zizLJlEUZS4qKspQKpWjDh48yB8Q3blCYzabPWmaHknTtB9FUX6EkJ+6gpG7mkym+3K5fCr3vgt6vX6YRqPh9vNfNuUGA1gBQooBYubCrBvQB0gv0CxrKTebzWsUCoWQq54vUmzcAFwEayZ4fBJo+AqoW/FiaEgGWrMAy1NiMpnKcnNzg0NCQvpX5wlwHHQLQd3HgGouoIqxg7nPf1+zEOiohU6nK4uNjRU9lwAhZCYIS1C/yoFRKYh6DegH6aCaM0CavgaqZPaJ1H4IzpsKhWJrXFyck92AoyhKRAj5GYabgCq6j49Fw1Sfij1p2xAzR4rAUd4I8BsBmTQSP+7cCn3dLjv7YoAnl1BXV1uZnZ09vqWlhd9XwMkBWKwR1ZrTh2vnoO7OYcyYPhVR072QlToZ9/IjUf2bBDk7X0dMhAhvvjEJd25kWtfaeK0ltauIMjqdLjsoKMjjGQGLxRLWLa0AzX6bP9DXpmFa6BR8utgPdMVsoPFLQHca0P0CNH0LS2U01n8+BuPHjcWDu3sBVS9Jmr9D97F27drlEydO7PQEwzBzu+j1SaB6PrZsWgfp215gKmTAk8vWZY2Njbhy5Qpomgb010BU0VgkEyMh4QuQmsUOCSQnJ28Wi8WD+0WAbU7FhNeCcOFgCNC88dlSi8WC8PBwREREwGAwAA/TcfPsDAQGjERHIxcP8+wSWL169RZvb+/BXTEQY1+CeXik2geBwA3aW7OA9t+tf0wIAcuyVuNCoRCZmZmAUQnqrhR+Pp6oLt3dM456EUhKStosEok6CWg0Gh+WZdv6JjAfzeXpEAhc8fQvCfD0Nk6cOIENGzZgyZIlcHZ2hqurK7Zt2wZ03IelMgpBAUNx9+YuuxJotVrT5MmTP3Nzc+vsnKmpqXy5XB6jUCjyTSaTobcEZnUGRF7DUXY+HGg9ZNXe19cXTk5O4PP51rlKpbIGZH2BBN4jPKGr3WsjAU3TzKlTp27LZLI0gUAQ0CMVJ0yYwP/3hYfFwvxtE4T347F82RIkLBsFUr0AoJpQXl6OxMREJCQkoLS0FKAfAzWLsTkxCAsWzAdpSLLxgNFoNLm7uy90dnYW2CtGgwghZbZpKIXyxgEE+HshLysEpOYDoO0SCKMHYZ4C7VeB2o9QeGo6fLyFuK440GcacgSEQqHUUR/gCNzGo0O2lazmPZzI3oGgAC/8kBIEbckskKpIkCoJ2ktnIW3deIzy9UTG7u9BapfZ7m/exGWKUSAQSJ935v8VTy701O8ZiffxhyIT0bIo+IrcMTPUB+9M84W/ryckEWFQXNwP1C3vu3+0HoFarW4Vi8VhDjuh2WxeCYsRqLbX4WQg6m9QfSsduafTkHt6NyqL0sE2bbR1e7c9oFpw7ty54uDg4DEOu2F+fr6QYZha6K86+OD/XbETjlqyDNCehdFgMEdFRW1wdXV1cUjgzJkzvOLi4kiGYdphKLFmAO5FAPfCOqEK6znvft8DM4G6OKD9GhiGsaxfvz5XJBIF9+tElJiYOOjkyZMSjUajJNzZgNYR0tH4YqAeE+5c0dDQ8HjlypVH/fz83uLxeP0/H4aHh/MDAwNF27dv/0Qulx85duzYpaNHj+ZxyMnJyeuad0f354cPHz6fnJycPnr06EVeXl7eL2S81+DPnj3bRSqVukskEo/+IjQ01J3H47kMHz7coeF/AG5SlP8HdQqpAAAAAElFTkSuQmCC" width="16" height="16"/>`}};function a(e){let[,t,n]=e.split(`/`);return!t||!n?null:{owner:t,repo:n}}var o=[{labelKey:`ways.diagram`,service:`GitDiagram`,icon:i.gitdiagram,group:`structure`,url:e=>`https://gitdiagram.com/${e.owner}/${e.repo}`},{labelKey:`ways.depgraph`,service:`Dependency`,icon:i.depgraph,group:`structure`,url:e=>`https://github.com/${e.owner}/${e.repo}/network/dependencies`},{labelKey:`ways.explainer`,service:`DeepWiki`,icon:i.deepwiki,group:`ai`,url:e=>`https://deepwiki.com/${e.owner}/${e.repo}`},{labelKey:`ways.zread`,service:`Zread`,icon:i.zread,group:`ai`,url:e=>`https://zread.ai/${e.owner}/${e.repo}`},{labelKey:`ways.prompts`,service:`GitReverse`,icon:i.gitreverse,group:`ai`,url:e=>`https://gitreverse.com/${e.owner}/${e.repo}`},{labelKey:`ways.mcp`,service:`GitMCP`,icon:i.mcp,group:`ai`,url:e=>`https://gitmcp.io/${e.owner}/${e.repo}`},{labelKey:`ways.package`,service:`Gitingest`,icon:i.gitingest,group:`ai`,url:e=>`https://gitingest.com/${e.owner}/${e.repo}`},{labelKey:`ways.read`,service:`GitHub1s`,icon:i.github1s,group:`code`,url:e=>`https://github1s.com/${e.owner}/${e.repo}`},{labelKey:`ways.edit`,service:`GitHub.dev`,icon:i.githubdev,group:`code`,url:e=>`https://github.dev/${e.owner}/${e.repo}`},{labelKey:`ways.codespaces`,service:`Codespaces`,icon:i.codespaces,group:`code`,url:e=>`https://codespaces.new/${e.owner}/${e.repo}`},{labelKey:`ways.run`,service:`StackBlitz`,icon:i.stackblitz,group:`code`,url:e=>`https://stackblitz.com/github/${e.owner}/${e.repo}`},{labelKey:`ways.ossinsight`,service:`OSSInsight`,icon:i.ossinsight,group:`analytics`,url:e=>`https://ossinsight.io/analyze/${e.owner}/${e.repo}`}],s=`repoways-ui`,c=`button[data-component="Button"][data-variant="primary"][aria-haspopup="true"]`,l=`#ref-picker-repos-header-ref-selector`,u=[`background-color`,`box-shadow`,`color`,`border-width`,`border-style`,`border-color`,`border-radius`,`padding`,`gap`,`font-family`,`font-size`,`font-weight`,`line-height`],d=[`data-color-mode`,`data-light-theme`,`data-dark-theme`],f=`http://www.w3.org/2000/svg`,p=`168 162 700 700`,m=`var(--fgColor-muted, currentColor)`,h=`<g fill="none" stroke="currentColor" stroke-width="64" stroke-linecap="round" stroke-linejoin="round"><path stroke="${m}" d="M319.8 480.7L644.2 299.3"/><path stroke="${m}" d="M328 512L708 512"/><path stroke="${m}" d="M319.8 543.3L644.2 724.7"/><circle cx="264" cy="512" r="64"/><circle cx="700" cy="268" r="64"/><circle cx="772" cy="512" r="64"/><circle cx="700" cy="756" r="64"/></g>`,g=`m4.427 7.427 3.396 3.396a.25.25 0 0 0 .354 0l3.396-3.396A.25.25 0 0 0 11.396 7H4.604a.25.25 0 0 0-.177.427Z`;function _(e){let t=document.createElementNS(f,`svg`);return t.setAttribute(`viewBox`,`0 0 16 16`),t.setAttribute(`width`,`16`),t.setAttribute(`height`,`16`),t.setAttribute(`fill`,`currentColor`),t.setAttribute(`aria-hidden`,`true`),t.innerHTML=`<path d="${e}"></path>`,t}function v(){let e=document.createElementNS(f,`svg`);return e.setAttribute(`viewBox`,p),e.setAttribute(`width`,`16`),e.setAttribute(`height`,`16`),e.setAttribute(`aria-hidden`,`true`),e.innerHTML=h,e}function y(e){let t=document.createElementNS(f,`svg`);return t.setAttribute(`viewBox`,e.viewBox),t.setAttribute(`class`,`rw-icon`),t.setAttribute(`aria-hidden`,`true`),t.innerHTML=e.body,t}function b(e,t,i){let a=document.createElement(s),c=a.attachShadow({mode:`open`});c.innerHTML=`<style>${r}</style>`;let l=document.createElement(`div`);l.className=`rw`;let d=document.createElement(`button`);d.type=`button`,d.className=`rw-btn`,d.setAttribute(`aria-haspopup`,`true`),d.setAttribute(`aria-expanded`,`false`),d.style.height=getComputedStyle(e).height;let f=()=>{if(!t)return;let e=getComputedStyle(t);for(let t of u){let n=e.getPropertyValue(t);n&&d.style.setProperty(t,n)}};f();let p=document.createElement(`span`);p.textContent=n(`button.label`),d.append(v(),p,_(g));let m=document.createElement(`div`);m.className=`rw-menu`,m.hidden=!0;let h=null;for(let e of o){if(h!==null&&e.group!==h){let e=document.createElement(`div`);e.className=`rw-divider`,e.setAttribute(`aria-hidden`,`true`),m.append(e)}h=e.group;let t=document.createElement(`a`);t.className=`rw-item`,t.href=e.url(i),t.target=`_blank`,t.rel=`noopener noreferrer`;let r=document.createElement(`span`);r.className=`rw-name`,r.textContent=e.service;let a=document.createElement(`span`);a.className=`rw-lead`,a.append(y(e.icon),r);let o=document.createElement(`span`);o.className=`rw-desc`,o.textContent=n(e.labelKey),t.append(a,o),m.append(t)}l.append(d,m),c.append(l);let b=()=>{let e=d.getBoundingClientRect(),{offsetWidth:t,offsetHeight:n}=m,r=Math.max(8,Math.min(e.right-t,window.innerWidth-t-8)),i=window.innerHeight-e.bottom-4-8,a=e.top-4-8;m.style.left=`${r}px`,m.style.top=`${i<n&&a>i?e.top-4-n:e.bottom+4}px`},x=()=>{m.hidden=!1,d.setAttribute(`aria-expanded`,`true`),b()},S=()=>{m.hidden=!0,d.setAttribute(`aria-expanded`,`false`)};d.addEventListener(`click`,()=>{m.hidden?x():S()}),m.addEventListener(`click`,e=>{e.target?.closest(`.rw-item`)&&S()});let C=e=>{!m.hidden&&!e.composedPath().includes(a)&&S()},w=e=>{e.key===`Escape`&&!m.hidden&&S()},T=()=>{m.hidden||b()};return window.addEventListener(`pointerdown`,C,!0),window.addEventListener(`keydown`,w),window.addEventListener(`scroll`,T,!0),window.addEventListener(`resize`,T),{host:a,donor:t,restyle:f,destroy:()=>{window.removeEventListener(`pointerdown`,C,!0),window.removeEventListener(`keydown`,w),window.removeEventListener(`scroll`,T,!0),window.removeEventListener(`resize`,T)}}}var x=null;function S(){x?.destroy(),document.querySelectorAll(s).forEach(e=>e.remove()),x=null}function C(){let e=document.querySelector(c),t=document.querySelector(l);if(x?.host.isConnected&&x.host.nextElementSibling===e&&x.donor===t)return;let n=e?.parentElement,r=a(location.pathname);if(!e||!n||!r){S();return}S(),x=b(e,t,r),n.insertBefore(x.host,e)}var w=e({matches:[`https://github.com/*`],runAt:`document_idle`,main(e){C();let t=new MutationObserver(C);t.observe(document.documentElement,{childList:!0,subtree:!0});let n=new MutationObserver(()=>x?.restyle());n.observe(document.documentElement,{attributeFilter:d}),document.addEventListener(`turbo:load`,C),e.onInvalidated(()=>{t.disconnect(),n.disconnect(),document.removeEventListener(`turbo:load`,C)})}}),T={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},E=class e extends Event{static EVENT_NAME=D(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function D(e){return`${t?.runtime?.id}:content:${e}`}var O=typeof globalThis.navigation?.addEventListener==`function`;function k(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),O?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new E(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new E(e,t)),t=e)},1e3))}}}var A=class e{static SCRIPT_STARTED_MESSAGE_TYPE=D(`wxt:content-script-started`);id;abortController;locationWatcher=k(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?D(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),T.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},j={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=w;return await e(new A(`content`,t))}catch(e){throw j.error(`The content script "content" crashed on startup!`,e),e}})()})();