(function(){var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t),e=null),t.exports),s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},c=(n,r,o)=>(o=n==null?{}:e(i(n)),s(r||!n||!n.__esModule||!a.call(n,`default`)?t(o,`default`,{value:n,enumerable:!0}):o,n));function l(e){return e}var u={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},d=Symbol(`null`),f=0,p=class extends Map{constructor(...e){super(),this._objectHashes=new WeakMap,this._symbolHashes=new Map,this._publicKeys=new Map;let[t]=e;if(t!=null){if(typeof t[Symbol.iterator]!=`function`)throw TypeError(typeof t+` is not iterable (cannot read property Symbol(Symbol.iterator))`);for(let[e,n]of t)this.set(e,n)}}_getPublicKeys(e,t=!1){if(!Array.isArray(e))throw TypeError(`The keys parameter must be an array`);let n=this._getPrivateKey(e,t),r;return n&&this._publicKeys.has(n)?r=this._publicKeys.get(n):t&&(r=[...e],this._publicKeys.set(n,r)),{privateKey:n,publicKey:r}}_getPrivateKey(e,t=!1){let n=[];for(let r of e){let e=r===null?d:r,i;if(i=typeof e==`object`||typeof e==`function`?`_objectHashes`:typeof e==`symbol`&&`_symbolHashes`,!i)n.push(e);else if(this[i].has(e))n.push(this[i].get(e));else if(t){let t=`@@mkm-ref-${f++}@@`;this[i].set(e,t),n.push(t)}else return!1}return JSON.stringify(n)}set(e,t){let{publicKey:n}=this._getPublicKeys(e,!0);return super.set(n,t)}get(e){let{publicKey:t}=this._getPublicKeys(e);return super.get(t)}has(e){let{publicKey:t}=this._getPublicKeys(e);return super.has(t)}delete(e){let{publicKey:t,privateKey:n}=this._getPublicKeys(e);return!!(t&&super.delete(t)&&this._publicKeys.delete(n))}clear(){super.clear(),this._symbolHashes.clear(),this._publicKeys.clear()}get[Symbol.toStringTag](){return`ManyKeysMap`}get size(){return super.size}};function m(e){if(typeof e!=`object`||!e)return!1;let t=Object.getPrototypeOf(e);return t!==null&&t!==Object.prototype&&Object.getPrototypeOf(t)!==null||Symbol.iterator in e?!1:Symbol.toStringTag in e?Object.prototype.toString.call(e)===`[object Module]`:!0}function h(e,t,n=`.`,r){if(!m(t))return h(e,{},n,r);let i={...t};for(let t of Object.keys(e)){if(t===`__proto__`||t===`constructor`)continue;let a=e[t];a!=null&&(r&&r(i,t,a,n)||(i[t]=Array.isArray(a)&&Array.isArray(i[t])?[...a,...i[t]]:m(a)&&m(i[t])?h(a,i[t],(n?`${n}.`:``)+t.toString(),r):a))}return i}function g(e){return(...t)=>t.reduce((t,n)=>h(t,n,``,e),{})}var _=g(),v=e=>e===null?{isDetected:!1}:{isDetected:!0,result:e},y=e=>e===null?{isDetected:!0,result:null}:{isDetected:!1},b=()=>({target:globalThis.document,unifyProcess:!0,detector:v,observeConfigs:{childList:!0,subtree:!0,attributes:!0},signal:void 0,customMatcher:void 0}),x=(e,t)=>_(e,t),S=new p;function C(e){let{defaultOptions:t}=e;return(e,n)=>{let{target:r,unifyProcess:i,observeConfigs:a,detector:o,signal:s,customMatcher:c}=x(n,t),l=[e,r,i,a,o,s,c],u=S.get(l);if(i&&u)return u;let d=new Promise(async(t,n)=>{if(s?.aborted)return n(s.reason);let i=new MutationObserver(async n=>{for(let a of n){if(s?.aborted){i.disconnect();break}let n=await w({selector:e,target:r,detector:o,customMatcher:c});if(n.isDetected){i.disconnect(),t(n.result);break}}});s?.addEventListener(`abort`,()=>(i.disconnect(),n(s.reason)),{once:!0});let l=await w({selector:e,target:r,detector:o,customMatcher:c});if(l.isDetected)return t(l.result);i.observe(r,a)}).finally(()=>{S.delete(l)});return S.set(l,d),d}}async function w({target:e,selector:t,detector:n,customMatcher:r}){return await n(r?r(t):e.querySelector(t))}var T=C({defaultOptions:b()});function E(e,t,n){n.position!==`inline`&&(n.zIndex!=null&&(e.style.zIndex=String(n.zIndex)),e.style.overflow=`visible`,e.style.position=`relative`,e.style.width=`0`,e.style.height=`0`,e.style.display=`block`,t&&(n.position===`overlay`?(t.style.position=`absolute`,n.alignment?.startsWith(`bottom-`)?t.style.bottom=`0`:t.style.top=`0`,n.alignment?.endsWith(`-right`)?t.style.right=`0`:t.style.left=`0`):(t.style.position=`fixed`,t.style.top=`0`,t.style.bottom=`0`,t.style.left=`0`,t.style.right=`0`)))}function D(e){if(e.anchor==null)return document.body;let t=typeof e.anchor==`function`?e.anchor():e.anchor;return typeof t==`string`?t.startsWith(`/`)?document.evaluate(t,document,null,XPathResult.FIRST_ORDERED_NODE_TYPE,null).singleNodeValue??void 0:document.querySelector(t)??void 0:t??void 0}function O(e,t){let n=D(t);if(n==null)throw Error(`Failed to mount content script UI: could not find anchor element`);switch(t.append){case void 0:case`last`:n.append(e);break;case`first`:n.prepend(e);break;case`replace`:n.replaceWith(e);break;case`after`:n.parentElement?.insertBefore(e,n.nextElementSibling);break;case`before`:n.parentElement?.insertBefore(e,n);break;default:t.append(n,e)}}function k(e,t){let n,r=()=>{n?.stopAutoMount(),n=void 0},i=()=>{e.mount()},a=e.remove;return{mount:i,remove:()=>{r(),e.remove()},autoMount:e=>{n&&u.warn(`autoMount is already set.`),n=A({mount:i,unmount:a,stopAutoMount:r},{...t,...e})}}}function A(e,t){let n=new AbortController,r=`explicit_stop_auto_mount`,i=()=>{n.abort(r),t.onStop?.()},a=typeof t.anchor==`function`?t.anchor():t.anchor;if(a instanceof Element)throw Error("autoMount and Element anchor option cannot be combined. Avoid passing `Element` directly or `() => Element` to the anchor.");async function o(i){let a=!!D(t);for(a&&e.mount();!n.signal.aborted;)try{a=!!await T(i??`body`,{customMatcher:()=>D(t)??null,detector:a?y:v,signal:n.signal}),a?e.mount():(e.unmount(),t.once&&e.stopAutoMount())}catch(e){if(n.signal.aborted&&n.signal.reason===r)break;throw e}}return o(a),{stopAutoMount:i}}var j=/(\s*@(property|font-face)[\s\S]*?{[\s\S]*?})/gm;function ee(e){return{documentCss:Array.from(e.matchAll(j),e=>e[0]).join(``).trim(),shadowCss:e.replace(j,``).trim()}}var M=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,N=M,P=c(o(((e,t)=>{var n=/^[a-z](?:[\.0-9_a-z\xB7\xC0-\xD6\xD8-\xF6\xF8-\u037D\u037F-\u1FFF\u200C\u200D\u203F\u2040\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]|[\uD800-\uDB7F][\uDC00-\uDFFF])*-(?:[\x2D\.0-9_a-z\xB7\xC0-\xD6\xD8-\xF6\xF8-\u037D\u037F-\u1FFF\u200C\u200D\u203F\u2040\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]|[\uD800-\uDB7F][\uDC00-\uDFFF])*$/;t.exports=function(e){return n.test(e)}}))(),1),F=[`article`,`aside`,`blockquote`,`body`,`div`,`footer`,`h1`,`h2`,`h3`,`h4`,`h5`,`h6`,`header`,`main`,`nav`,`p`,`section`,`span`];async function I(e){let{name:t,mode:n=`closed`,css:r,isolateEvents:i=!1}=e;if(!F.includes(t)&&!(0,P.default)(t))throw Error(`"${t}" cannot have a shadow root attached to it. It must be two words and kebab-case, with a few exceptions. See https://developer.mozilla.org/en-US/docs/Web/API/Element/attachShadow#elements_you_can_attach_a_shadow_to`);let a=document.createElement(t),o=a.attachShadow({mode:n}),s=document.createElement(`div`);if(r){let e=document.createElement(`style`);e.textContent=`url`in r?await fetch(r.url).then(e=>e.text()):r.textContent,o.appendChild(e)}return o.appendChild(s),i&&(Array.isArray(i)?i:[`keydown`,`keyup`,`keypress`]).forEach(e=>{o.addEventListener(e,e=>e.stopPropagation())}),{parentElement:a,shadow:o,isolatedElement:s}}async function L(e,t){let n=Math.random().toString(36).substring(2,15),r=[];if(t.inheritStyles||r.push(`/* WXT Shadow Root Reset */ :host{all:initial !important;}`),t.css&&r.push(t.css),e.options?.cssInjectionMode===`ui`){let e=await R();r.push(e.replaceAll(`:root`,`:host`))}let{shadowCss:i,documentCss:a}=ee(r.join(`
`).trim()),{isolatedElement:o,parentElement:s,shadow:c}=await I({name:t.name,css:{textContent:i},mode:t.mode??`open`,isolateEvents:t.isolateEvents}),l,u=()=>{if(O(s,t),E(s,o,t),a&&!document.querySelector(`style[wxt-shadow-root-document-styles="${n}"]`)){let e=document.createElement(`style`);e.textContent=a,e.setAttribute(`wxt-shadow-root-document-styles`,n),(document.head??document.body).append(e)}l=t.onMount(o,c,s)},d=()=>{for(t.onRemove?.(l),s.remove(),document.querySelector(`style[wxt-shadow-root-document-styles="${n}"]`)?.remove();o.lastChild;)o.removeChild(o.lastChild);l=void 0},f=k({mount:u,remove:d},t);return e.onInvalidated(d),{shadow:c,shadowHost:s,uiContainer:o,...f,get mounted(){return l}}}async function R(){let e=N.runtime.getURL(`/content-scripts/content.css`);try{return await(await fetch(e)).text()}catch(t){return u.warn(`Failed to load styles @ ${e}. Did you forget to import the stylesheet in your entrypoint?`,t),``}}function z(e){return e.replace(/[^a-zA-Z0-9_@]/g,`_`)}function B(e,t){let n=t?Object.values(t).map(String):void 0;return N.i18n.getMessage(z(e),n)||e}function V(){return{t:(e,t)=>B(e,t)}}var H=o(((e,t)=>{var n=class{constructor(e){this.data=e}},r=class{constructor(){this.length=0}enqueue(e){let t=new n(e);return t.prev=this.tail,this.tail?this.tail.next=t:this.head=t,this.tail=t,this.length++,t}dequeue(){if(!this.head)return;let{data:e}=this.head;return this.remove(this.head),e}remove(e){e.prev?e.prev.next=e.next:this.head=e.next,e.next?e.next.prev=e.prev:this.tail=e.prev,this.length--}size(){return this.length}};t.exports=(e=1)=>{let t=new r,n=()=>{++e;let n=t.dequeue();if(n)return n.acquire()},i=t=>{--e,t(n)},a=e=>new Promise(n=>{if(e!=null&&typeof e.addEventListener!=`function`)throw TypeError("`signal` needs to be an AbortSignal.");if(e?.aborted)return n(null);if(!a.isLocked())return i(n);let r={acquire:()=>i(n)},o=t.enqueue(r);if(e!=null){let a=()=>{t.remove(o),n(null)};r.acquire=()=>{e.removeEventListener(`abort`,a),i(n)},e.addEventListener(`abort`,a,{once:!0})}});return a.isLocked=()=>e===0,a.awaiting=()=>t.size(),a}})),U=o(((e,t)=>{var n=H();t.exports={withLock:e=>{let t=n(e),r=async(e,n)=>{let r=await t(n);if(r)try{return await e()}finally{r()}};return r.isLocked=t.isLocked,r.awaiting=t.awaiting,r},createLock:n}}))(),W=Object.prototype.hasOwnProperty;function G(e,t){var n,r;if(e===t)return!0;if(e&&t&&(n=e.constructor)===t.constructor){if(n===Date)return e.getTime()===t.getTime();if(n===RegExp)return e.toString()===t.toString();if(n===Array){if((r=e.length)===t.length)for(;r--&&G(e[r],t[r]););return r===-1}if(!n||typeof e==`object`){for(n in r=0,e)if(W.call(e,n)&&++r&&!W.call(t,n)||!(n in t)||!G(e[n],t[n]))return!1;return Object.keys(t).length===r}}return e!==e&&t!==t}var te=ne();function ne(){let e={local:re(`local`),session:re(`session`),sync:re(`sync`),managed:re(`managed`)},t=t=>{let n=e[t];if(n==null){let n=Object.keys(e).join(`, `);throw Error(`Invalid area "${t}". Options: ${n}`)}return n},n=e=>{let n=e.indexOf(`:`),r=e.substring(0,n),i=e.substring(n+1);if(i==null)throw Error(`Storage key should be in the form of "area:key", but received "${e}"`);return{driverArea:r,driverKey:i,driver:t(r)}},r=e=>e+`$`,i=(e,t)=>{let n={...e};return Object.entries(t).forEach(([e,t])=>{t==null?delete n[e]:n[e]=t}),n},a=(e,t)=>e??t??null,o=e=>typeof e==`object`&&!Array.isArray(e)?e:{},s=async(e,t,n)=>a(await e.getItem(t),n?.fallback??n?.defaultValue),c=async(e,t)=>{let n=r(t);return o(await e.getItem(n))},l=async(e,t,n)=>{await e.setItem(t,n??null)},u=async(e,t,n)=>{let a=r(t),s=o(await e.getItem(a));await e.setItem(a,i(s,n))},d=async(e,t,n)=>{if(await e.removeItem(t),n?.removeMeta){let n=r(t);await e.removeItem(n)}},f=async(e,t,n)=>{let i=r(t);if(n==null)await e.removeItem(i);else{let t=o(await e.getItem(i));[n].flat().forEach(e=>delete t[e]),await e.setItem(i,t)}},p=(e,t,n)=>e.watch(t,n);return{getItem:async(e,t)=>{let{driver:r,driverKey:i}=n(e);return await s(r,i,t)},getItems:async t=>{let r=new Map,i=new Map,o=[];t.forEach(e=>{let t,a;typeof e==`string`?t=e:`getValue`in e?(t=e.key,a={fallback:e.fallback}):(t=e.key,a=e.options),o.push(t);let{driverArea:s,driverKey:c}=n(t),l=r.get(s)??[];r.set(s,l.concat(c)),i.set(t,a)});let s=new Map;return await Promise.all(Array.from(r.entries()).map(async([t,n])=>{(await e[t].getItems(n)).forEach(e=>{let n=`${t}:${e.key}`,r=i.get(n),o=a(e.value,r?.fallback??r?.defaultValue);s.set(n,o)})})),o.map(e=>({key:e,value:s.get(e)}))},getMeta:async e=>{let{driver:t,driverKey:r}=n(e);return await c(t,r)},getMetas:async e=>{let t=e.map(e=>{let t=typeof e==`string`?e:e.key,{driverArea:i,driverKey:a}=n(t);return{key:t,driverArea:i,driverKey:a,driverMetaKey:r(a)}}),i=t.reduce((e,t)=>(e[t.driverArea]??=[],e[t.driverArea].push(t),e),{}),a={};return await Promise.all(Object.entries(i).map(async([e,t])=>{let n=await M.storage[e].get(t.map(e=>e.driverMetaKey));t.forEach(e=>{a[e.key]=n[e.driverMetaKey]??{}})})),t.map(e=>({key:e.key,meta:a[e.key]}))},setItem:async(e,t)=>{let{driver:r,driverKey:i}=n(e);await l(r,i,t)},setItems:async e=>{let r={};e.forEach(e=>{let{driverArea:t,driverKey:i}=n(`key`in e?e.key:e.item.key);r[t]??=[],r[t].push({key:i,value:e.value})}),await Promise.all(Object.entries(r).map(async([e,n])=>{await t(e).setItems(n)}))},setMeta:async(e,t)=>{let{driver:r,driverKey:i}=n(e);await u(r,i,t)},setMetas:async e=>{let a={};e.forEach(e=>{let{driverArea:t,driverKey:r}=n(`key`in e?e.key:e.item.key);a[t]??=[],a[t].push({key:r,properties:e.meta})}),await Promise.all(Object.entries(a).map(async([e,n])=>{let a=t(e),s=n.map(({key:e})=>r(e)),c=await a.getItems(s),l=Object.fromEntries(c.map(({key:e,value:t})=>[e,o(t)])),u=n.map(({key:e,properties:t})=>{let n=r(e);return{key:n,value:i(l[n]??{},t)}});await a.setItems(u)}))},removeItem:async(e,t)=>{let{driver:r,driverKey:i}=n(e);await d(r,i,t)},removeItems:async e=>{let i={};e.forEach(e=>{let t,a;typeof e==`string`?t=e:`getValue`in e?t=e.key:`item`in e?(t=e.item.key,a=e.options):(t=e.key,a=e.options);let{driverArea:o,driverKey:s}=n(t);i[o]??=[],i[o].push(s),a?.removeMeta&&i[o].push(r(s))}),await Promise.all(Object.entries(i).map(async([e,n])=>{await t(e).removeItems(n)}))},clear:async e=>{await t(e).clear()},removeMeta:async(e,t)=>{let{driver:r,driverKey:i}=n(e);await f(r,i,t)},snapshot:async(e,n)=>{let i=await t(e).snapshot();return n?.excludeKeys?.forEach(e=>{delete i[e],delete i[r(e)]}),i},restoreSnapshot:async(e,n)=>{await t(e).restoreSnapshot(n)},watch:(e,t)=>{let{driver:r,driverKey:i}=n(e);return p(r,i,t)},unwatch(){Object.values(e).forEach(e=>{e.unwatch()})},defineItem:(e,t)=>{let{driver:i,driverKey:a}=n(e),{version:o=1,migrations:m={},onMigrationComplete:h,debug:g=!1}=t??{};if(o<1)throw Error(`Storage item version cannot be less than 1. Initial versions should be set to 1, not 0.`);let _=!1,v=async()=>{let t=r(a),[{value:n},{value:s}]=await i.getItems([a,t]);if(_=n==null&&s?.v==null&&!!o,n==null)return;let c=s?.v??1;if(c>o)throw Error(`Version downgrade detected (v${c} -> v${o}) for "${e}"`);if(c===o)return;g&&console.debug(`[@wxt-dev/storage] Running storage migration for ${e}: v${c} -> v${o}`);let l=Array.from({length:o-c},(e,t)=>c+t+1),u=n;for(let t of l)try{u=await m?.[t]?.(u)??u,g&&console.debug(`[@wxt-dev/storage] Storage migration processed for version: v${t}`)}catch(n){throw new ie(e,t,{cause:n})}await i.setItems([{key:a,value:u},{key:t,value:{...s,v:o}}]),g&&console.debug(`[@wxt-dev/storage] Storage migration completed for ${e} v${o}`,{migratedValue:u}),h?.(u,o)},y=t?.migrations==null?Promise.resolve():v().catch(t=>{console.error(`[@wxt-dev/storage] Migration failed for ${e}`,t)}),b=(0,U.withLock)(),x=()=>t?.fallback??t?.defaultValue??null,S=()=>b(async()=>{let e=await i.getItem(a);if(e!=null||t?.init==null)return e;let n=await t.init();return await i.setItem(a,n),e==null&&o>1&&await u(i,a,{v:o}),n});return y.then(S),{key:e,get defaultValue(){return x()},get fallback(){return x()},getValue:async()=>(await y,t?.init?await S():await s(i,a,t)),getMeta:async()=>(await y,await c(i,a)),setValue:async e=>{await y,_?(_=!1,await Promise.all([l(i,a,e),u(i,a,{v:o})])):await l(i,a,e)},setMeta:async e=>(await y,await u(i,a,e)),removeValue:async e=>(await y,await d(i,a,e)),removeMeta:async e=>(await y,await f(i,a,e)),watch:e=>p(i,a,(t,n)=>e(t??x(),n??x())),migrate:v}}}}function re(e){let t=()=>{if(M.runtime==null)throw Error(`'wxt/storage' must be loaded in a web extension environment

 - If thrown during a build, see https://github.com/wxt-dev/wxt/issues/371
 - If thrown during tests, mock 'wxt/browser' correctly. See https://wxt.dev/guide/go-further/testing.html
`);if(M.storage==null)throw Error(`You must add the 'storage' permission to your manifest to use 'wxt/storage'`);let t=M.storage[e];if(t==null)throw Error(`"browser.storage.${e}" is undefined`);return t},n=new Set;return{getItem:async e=>(await t().get(e))[e],getItems:async e=>{let n=await t().get(e);return e.map(e=>({key:e,value:n[e]??null}))},setItem:async(e,n)=>{n==null?await t().remove(e):await t().set({[e]:n})},setItems:async e=>{let n=e.reduce((e,{key:t,value:n})=>(e[t]=n,e),{});await t().set(n)},removeItem:async e=>{await t().remove(e)},removeItems:async e=>{await t().remove(e)},clear:async()=>{await t().clear()},snapshot:async()=>await t().get(),restoreSnapshot:async e=>{await t().set(e)},watch(e,r){let i=t=>{let n=t[e];n==null||G(n.newValue,n.oldValue)||r(n.newValue??null,n.oldValue??null)};return t().onChanged.addListener(i),n.add(i),()=>{t().onChanged.removeListener(i),n.delete(i)}},unwatch(){n.forEach(e=>{t().onChanged.removeListener(e)}),n.clear()}}}var ie=class extends Error{constructor(e,t,n){super(`v${t} migration failed for "${e}"`,n),this.key=e,this.version=t}},ae=[{id:`silver`,accent:`#94a3b8`,kind:`tint`},{id:`blue`,accent:`#4f6bf6`,kind:`tint`},{id:`gray`,accent:`#475569`,kind:`tint`},{id:`green`,accent:`#10b981`,kind:`tint`},{id:`purple`,accent:`#a855f7`,kind:`tint`},{id:`pink`,accent:`#ec4899`,kind:`tint`},{id:`orange`,accent:`#f97316`,kind:`tint`},{id:`cyan`,accent:`#06b6d4`,kind:`tint`},{id:`red`,accent:`#ef4444`,kind:`tint`},{id:`amber`,accent:`#f59e0b`,kind:`tint`},{id:`midnight`,accent:`#818cf8`,kind:`dark`,surface:`#1e2432`,ink:`#e7eaf0`},{id:`custom`,accent:`#4f6bf6`,kind:`tint`},{id:`auto`,accent:`#94a3b8`,kind:`tint`}],K=[{id:`google`,label:`Google`,url:`https://www.google.com/search?q=%s`},{id:`bing`,label:`Bing`,url:`https://www.bing.com/search?q=%s`},{id:`duckduckgo`,label:`DuckDuckGo`,url:`https://duckduckgo.com/?q=%s`}],oe=[{id:`google`,url:`https://translate.google.com/?sl=auto&tl=%t&op=translate&text=%s`,lang:{zh:`zh-CN`,en:`en`},openIn:`tab`,inline:!0},{id:`bing`,url:`https://www.bing.com/translator?text=%s&to=%t`,lang:{zh:`zh-Hans`,en:`en`},openIn:`preview`}],q=[{id:`kimi`,label:`Kimi`,url:`https://kimi.moonshot.cn/`},{id:`doubao`,label:`豆包`,url:`https://www.doubao.com/chat/`},{id:`perplexity`,label:`Perplexity`,url:`https://www.perplexity.ai/search?q=%s`},{id:`deepseek`,label:`DeepSeek`,url:`https://chat.deepseek.com/`}],se=[`auto`,`on`,`max`,`off`],ce=[`hover`,`click`,`altHover`,`longPress`,`drag`,`altClick`,`hoverSpace`],J=2e3,Y=1440;function le(e,t,n){if(!Number.isFinite(e)||e<=0)return n;let r=Math.round(e>100?e/t*100:e);return Math.min(100,Math.max(20,r))}function ue(e,t){return!Number.isFinite(e)||e<=0?t:Math.min(J,Math.max(200,Math.round(e)))}var X={enabled:!0,triggerMode:`hover`,hoverDelayMs:1e3,longPressMs:600,width:55,height:55,widthPx:800,heightPx:600,sizeUnit:`percent`,themeColor:`#4f6bf6`,windowColor:`#94a3b8`,position:`center`,sidebarSide:`right`,blurStrength:5,selectionSearch:!0,searchEngine:`google`,translateEngine:`bing`,aiEngine:`kimi`,openInBackground:!1,minSelectionChars:2,detectLinks:!0,maxWindows:3,speculationMode:`prefetch`,historyEnabled:!0,powerSaver:`auto`,reduceMotion:!1,highlightLinks:!0,highlightStyle:`dashed`,highlightWidth:2,highlightRadius:4,autoPin:!1,theme:`system`,windowTheme:`silver`,stripTracking:!0,warnDangerous:!0,skipImages:!1,rememberWindowGeom:!0,closeOnOutsideClick:!0,closeOnMouseLeave:!1,closeOnScroll:!1,closeOnEscape:!0,disabledSites:[]},Z=te.defineItem(`local:prelook_settings`,{defaultValue:X}),Q=te.defineItem(`local:prelook_history`,{defaultValue:[]});async function de(e){try{let t=await Q.getValue();await Q.setValue([e,...t.filter(t=>t.url!==e.url)].slice(0,100))}catch{}}async function fe(e,t,n){if(t||n)try{let r=await Q.getValue(),i=r.find(t=>t.url===e);if(!i)return;t&&(i.title=t),n&&(i.favicon=n),await Q.setValue(r)}catch{}}var pe=te.defineItem(`local:prelook_win_geom`,{defaultValue:{}});function me(e,t,n){let r={...e};delete r[t],r[t]=n;let i=Object.keys(r);for(let e of i.slice(0,Math.max(0,i.length-60)))delete r[e];return r}function he(e,t){let n=typeof e==`number`&&e>0?e:typeof t==`number`&&t>0?t*5:e??X.blurStrength;return Number.isFinite(n)?Math.min(100,Math.max(0,Math.round(n))):X.blurStrength}function ge(e,t){if(!e.length)return!1;let n=t.toLowerCase();return e.some(e=>{let t=e.toLowerCase().trim();return t?n===t||n.endsWith(`.${t}`):!1})}function $(e){let{blurPx:t,searchEngines:n,language:r,...i}=e,a=ae.some(t=>t.id===e.windowTheme)?e.windowTheme:X.windowTheme,o=e.sizeUnit===`px`?`px`:`percent`,s=e.widthPx===void 0&&e.heightPx===void 0,c=o===`px`&&s;return{...i,hoverDelayMs:Math.min(2e3,Math.max(100,e.hoverDelayMs||X.hoverDelayMs)),longPressMs:Math.min(2e3,Math.max(200,e.longPressMs||X.longPressMs)),width:le(e.width,Y,X.width),height:le(e.height,900,X.height),widthPx:ue(c?e.width:e.widthPx??X.widthPx,X.widthPx),heightPx:ue(c?e.height:e.heightPx??X.heightPx,X.heightPx),sizeUnit:o,blurStrength:he(i.blurStrength,t),minSelectionChars:Math.min(20,Math.max(1,e.minSelectionChars)),aiEngine:q.some(t=>t.id===e.aiEngine)?e.aiEngine:X.aiEngine,searchEngine:K.some(t=>t.id===e.searchEngine)?e.searchEngine:n?.find(e=>K.some(t=>t.id===e))??X.searchEngine,translateEngine:oe.some(t=>t.id===e.translateEngine)?e.translateEngine:X.translateEngine,theme:[`system`,`light`,`dark`].includes(e.theme)?e.theme:X.theme,powerSaver:se.includes(e.powerSaver)?e.powerSaver:X.powerSaver,triggerMode:ce.includes(e.triggerMode)?e.triggerMode:X.triggerMode,position:(()=>{let t=e.position,n=t===`center-top`?`top`:t===`center-bottom`?`bottom`:e.position;return[`top-left`,`top`,`top-right`,`left`,`center`,`right`,`bottom-left`,`bottom`,`bottom-right`,`sidebar`].includes(n)?n:X.position})(),highlightStyle:[`solid`,`dashed`].includes(e.highlightStyle)?e.highlightStyle:X.highlightStyle,highlightWidth:Math.min(6,Math.max(1,Math.round(e.highlightWidth||X.highlightWidth))),highlightRadius:Math.min(16,Math.max(0,Math.round(e.highlightRadius??X.highlightRadius))),windowTheme:a,themeColor:e.themeColor||X.themeColor,windowColor:e.windowColor||X.windowColor,maxWindows:Math.min(6,Math.max(1,e.maxWindows))}}var _e={level:`off`,reduceMotion:!1};function ve(e,t,n){let r=e===`auto`?t?`on`:`off`:e;return{level:r,reduceMotion:n||r===`max`}}function ye(){return typeof matchMedia==`function`?matchMedia(`(prefers-reduced-motion: reduce)`):null}function be(e,t){let n=ye(),r=null,i=!1,a=()=>{if(i)return;let a=$(e());t(ve(a.powerSaver,r?.charging===!1,a.reduceMotion||(n?.matches??!1)))},o=()=>a(),s=navigator.getBattery;return typeof s==`function`&&s.call(navigator).then(e=>{i||(r=e,e.addEventListener(`chargingchange`,o),a())}).catch(()=>{}),n?.addEventListener(`change`,a),a(),()=>{i=!0,n?.removeEventListener(`change`,a),r?.removeEventListener(`chargingchange`,o),r=null}}var xe=[`script`,`style`,`noscript`,`iframe`,`frame`,`object`,`embed`,`form`,`button`,`input`,`select`,`textarea`,`svg`,`canvas`,`video`,`audio`,`link`,`meta`,`header`,`footer`,`nav`,`aside`].join(`,`);function Se(e){let t=0,n=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);for(;n.nextNode();)t+=n.currentNode.textContent?.trim().length??0;return t}function Ce(e){if(!e)return null;let t=null,n=0,r=e.querySelectorAll(`article, main, section, div, td`),i=Math.min(r.length,400);for(let e=0;e<i;e++){let i=r[e],a=i.querySelectorAll(`p, li`);if(a.length<3)continue;let o=0;a.forEach(e=>{let t=e.textContent?.trim().length??0;t>40&&(o+=t)});let s=[...i.querySelectorAll(`a`)].reduce((e,t)=>e+(t.textContent?.trim().length??0),0);o>n&&s<o*2&&(n=o,t=i)}return t}var we={a:[`href`],img:[`src`,`alt`]};function Te(e,t){for(let n of Array.from(e.querySelectorAll(`*`))){let e=we[n.tagName.toLowerCase()]??[];for(let t of[...n.attributes])e.includes(t.name.toLowerCase())||n.removeAttribute(t.name);let r=n.getAttribute(`href`);if(r){if(/^\s*javascript:/i.test(r))n.removeAttribute(`href`);else try{n.setAttribute(`href`,new URL(r,t).href)}catch{n.removeAttribute(`href`)}}let i=n.getAttribute(`src`);if(i)try{n.setAttribute(`src`,new URL(i,t).href),n.setAttribute(`loading`,`lazy`),n.setAttribute(`referrerpolicy`,`no-referrer`)}catch{n.removeAttribute(`src`)}}}function Ee(e,t){let n;try{n=new DOMParser().parseFromString(e,`text/html`)}catch{return null}let r=n.querySelector(`meta[property="og:title"], meta[name="twitter:title"]`)?.getAttribute(`content`)?.trim()||n.title.trim()||void 0;n.body?.querySelectorAll(xe).forEach(e=>e.remove()),n.querySelectorAll(`[hidden]`).forEach(e=>e.remove());let i=[...n.querySelectorAll(`article, main, [role="main"]`)].sort((e,t)=>Se(t)-Se(e))[0]??null;if((!i||Se(i)<200)&&(i=Ce(n.body)??i),!i&&n.body&&Se(n.body)>=500&&(i=n.body),!i)return null;let a=Se(i)>=80,o=!!i.querySelector(`img`);if(!a&&!o)return null;Te(i,t);let s=i===n.body?i.innerHTML:i.outerHTML;return s.trim()?{title:r,html:s}:null}function De(e,t,n){let r=document.createElement(`div`);r.className=`tp-reader`;let i=document.createElement(`h1`);i.className=`tp-r-title`,i.textContent=e.title??Oe(n),r.appendChild(i);let a=document.createElement(`div`);return a.innerHTML=e.html,r.appendChild(a),r.addEventListener(`click`,e=>{let t=e.target.closest?.(`a[href]`);t&&(e.preventDefault(),e.stopPropagation(),N.runtime.sendMessage({type:`prelook:openTab`,url:t.href}))}),r}function Oe(e){try{return new URL(e).hostname}catch{return e}}var ke=[`--theme-color`,`--theme-color-primary`,`--primary-color`,`--primary`,`--main-color`,`--brand-color`,`--brand`,`--accent-color`,`--accent`,`--link-color`],Ae=40;function je(e){if(!e)return null;let t=e.trim();if(!t)return null;let n=/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(t)?.[1];if(n){let e=n.length===3?n.split(``).map(e=>e+e).join(``):n;return{r:parseInt(e.slice(0,2),16),g:parseInt(e.slice(2,4),16),b:parseInt(e.slice(4,6),16)}}let r=/^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)/i.exec(t);if(r){let[e,t,n]=[Number(r[1]),Number(r[2]),Number(r[3])];if([e,t,n].every(e=>Number.isFinite(e)))return{r:e,g:t,b:n}}return null}function Me(e,t,n){let r=Math.max(e,t,n),i=Math.min(e,t,n),a=(r+i)/2,o=r-i,s=o===0?0:o/(1-Math.abs(2*a-1)),c=0;return o!==0&&(c=r===e?(t-n)/o%6:r===t?(n-e)/o+2:(e-t)/o+4,c*=60,c<0&&(c+=360)),{h:c,s,l:a}}function Ne(e){let{h:t,s:n,l:r}=Me(e.r/255,e.g/255,e.b/255);return`hsl(${Math.round(t)} ${Math.round(n*100)}% ${Math.round(r*100)}%)`}function Pe(e){let t=Math.max(e.r,e.g,e.b),n=Math.min(e.r,e.g,e.b);return e.r===e.g&&e.g===e.b||t-n<8||n>236}function Fe(e){let{h:t,s:n,l:r}=Me(e.r/255,e.g/255,e.b/255),i=Math.min(68,Math.max(34,Math.round(r*100)));return Ie(t,Math.min(92,Math.max(n*100,n<.35?45:0))/100,i/100)}function Ie(e,t,n){let r=(1-Math.abs(2*n-1))*t,i=r*(1-Math.abs(e/60%2-1)),a=n-r/2,[o,s,c]=e<60?[r,i,0]:e<120?[i,r,0]:e<180?[0,r,i]:e<240?[0,i,r]:e<300?[i,0,r]:[r,0,i];return{r:Math.round((o+a)*255),g:Math.round((s+a)*255),b:Math.round((c+a)*255)}}function Le(e){return!e||Pe(e)?null:Ne(Fe(e))}var Re=/^\s*var\(\s*(--[a-z0-9_-]+)\s*\)\s*$/i,ze=/(#[0-9a-f]{3,8}|rgba?\([^)]*\))/i;function Be(e){return!!e.documentElement}function Ve(e){return e?e.defaultView??null:null}function He(e,t){let n=e.getAttribute(`style`);if(!n)return null;for(let e of n.split(`;`)){let n=e.indexOf(`:`);if(!(n<0)&&e.slice(0,n).trim().toLowerCase()===t.toLowerCase())return e.slice(n+1).trim()||null}return null}function Ue(e,t,n,r){let i=e,a=t,o=new Set;for(let e=0;e<24&&i;e+=1){let e=``;if(e=n?(r?r.getComputedStyle(i):getComputedStyle(i)).getPropertyValue(a).trim():He(i,a)?.trim()??``,!e){i=i.parentElement;continue}if(je(e))return e;let t=Re.exec(e)?.[1];if(!t||o.has(t.toLowerCase()))return null;o.add(t.toLowerCase()),a=t,i=i.parentElement}return null}function We(e,t,n){for(let r of ke){let i=Le(je(Ue(e,r,t,n)));if(i)return i}return null}function Ge(e){let t=Be(e)?e:e.ownerDocument;if(!t)return[];let n=[];for(let e of t.styleSheets){let t;try{t=e.cssRules}catch{continue}if(t&&(Ke(t,n),n.length>=8))return n}return n}function Ke(e,t){for(let n of Array.from(e)){if(t.length>=8)return;let e=n.cssRules;if(e){Ke(e,t);continue}let r=n instanceof CSSStyleRule?n.selectorText:``;if(r&&ke.some(e=>n.cssText.includes(`${e}:`)))for(let e of r.split(`,`)){let n=e.trim();/^\.[\w-]+(?:\s*>\s*\.[\w-]+)*$/.test(n)&&n.length<=64&&t.push(n)}}}function qe(e){let t=[];Be(e)?(e.documentElement&&t.push(e.documentElement),e.body&&e.body!==e.documentElement&&t.push(e.body)):t.push(e);for(let n of e.querySelectorAll(`*[style]`))if(t.push(n),t.length>16)break;for(let n of Ge(e)){try{let r=e.querySelector(n);r&&!t.includes(r)&&t.push(r)}catch{}if(t.length>24)break}return t}function Je(e,t,n){for(let r of qe(e)){let e=We(r,t,n);if(e)return e}return null}function Ye(e){for(let t of e.querySelectorAll(`style`)){let e=t.textContent;if(e)for(let t of ke){let n=e.indexOf(`${t}:`);if(n<0)continue;let r=e.slice(n+t.length+1,n+t.length+40);if(/^\s*var\(/i.test(r))continue;let i=Le(je(ze.exec(r)?.[1]));if(i)return i}}return null}function Xe(e,t,n){let r=new Map,i=0;for(let a of e.querySelectorAll(`a[href]`)){if(i>=Ae)break;i+=1;let e=n?n.getComputedStyle(a):getComputedStyle(a),o=t?je(e.color):null,s=null;if(!o||Pe(o))for(let n of ke){let r=je(t?e.getPropertyValue(n).trim():He(a,n)?.trim()??``);if(r&&!Pe(r)){s=r;break}}if(s&&(!o||Pe(o))&&(o=s),!o||Pe(o))continue;let c=`${o.r},${o.g},${o.b}`;r.set(c,(r.get(c)??0)+1)}let a=null,o=2;for(let[e,t]of r)t>o&&(a=e,o=t);if(!a)return null;let[s,c,l]=a.split(`,`).map(Number);return Le({r:s??0,g:c??0,b:l??0})}function Ze(e){try{let t=Le(je(e.querySelector(`meta[name="theme-color" i]`)?.content));if(t)return t;let n=Ve(Be(e)?e:e.ownerDocument);return n?Je(e,!0,n)??Xe(e,!0,n):Je(e,!1,null)??Ye(e)}catch{return null}}function Qe(){return Ze(document)}var $e=8e3,et=.5,tt=2600,nt=`viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"`,rt=`<svg ${nt}><path d="M10 3h4v6l3 3v2H7v-2l3-3z"/><path d="M12 14v7"/></svg>`,it=`<svg ${nt}><polyline points="22 4 22 10 16 10"/><path d="M19.5 15a8 8 0 1 1-1.9-8.3L22 10"/></svg>`,at=`<svg ${nt}><path d="M7 17 17 7"/><polyline points="8 7 17 7 17 16"/></svg>`,ot=`<svg ${nt}><path d="M6 6l12 12M18 6 6 18"/></svg>`;function st(e,t){let n=document.createElement(`div`);n.className=`tp-progress`;let r=document.createElement(`div`);r.className=`tp-progress-fill`,n.appendChild(r),e.appendChild(n);function i(e,i,a){if(t.reduceMotion())return;r.style.transition=`none`,r.style.width=`0`,n.style.setProperty(`--tp-accent`,t.getAccent()),n.classList.add(`tp-show`);let o=n.offsetWidth||72,s=n.offsetHeight||6,c=e-o/2,l=Math.min(Math.max(8,c),Math.max(8,innerWidth-o-8)),u=i-18-s,d=Math.min(i+18,Math.max(8,innerHeight-s-8)),f=u>=8?u:d;n.style.left=`${l}px`,n.style.top=`${f}px`,requestAnimationFrame(()=>{requestAnimationFrame(()=>{r.style.transition=`width ${a}ms linear`,r.style.width=`100%`})})}function a(){n.classList.remove(`tp-show`),r.style.transition=`none`,r.style.width=`0`}function o(e){n.style.setProperty(`--tp-accent`,e)}return{start:i,cancel:a,setAccent:o}}function ct(e,t){let n=document.createElement(`div`);n.className=`tp-notice`,e.appendChild(n);let r;function i(e,i,a,o){n.textContent=t.t(e,o),n.classList.add(`tp-show`);let s=n.offsetWidth,c=n.offsetHeight,l=Math.min(Math.max(8,i-s/2),Math.max(8,innerWidth-s-8)),u=a-18-c,d=Math.min(a+18,Math.max(8,innerHeight-c-8));n.style.left=`${l}px`,n.style.top=`${u>=8?u:d}px`,r&&clearTimeout(r),r=setTimeout(()=>n.classList.remove(`tp-show`),tt)}function a(){r&&clearTimeout(r)}return{show:i,clear:a}}function lt(e){let t=document.createElement(`div`);t.className=`tp-hl`,e.appendChild(t);let n=null,r=2;function i(e){if(n=e,!n){t.classList.remove(`tp-show`);return}a(),t.classList.add(`tp-show`)}function a(){if(!n)return;if(!n.isConnected){n=null,t.classList.remove(`tp-show`);return}let e=n.getBoundingClientRect();t.style.left=`${e.left-r}px`,t.style.top=`${e.top-r}px`,t.style.width=`${e.width+r*2}px`,t.style.height=`${e.height+r*2}px`}function o(e,n,i,a){t.style.setProperty(`--tp-accent`,e),t.style.setProperty(`--tp-hlw`,`${i}px`),t.style.setProperty(`--tp-hlr`,`${a}px`),r=i,t.classList.toggle(`tp-dashed`,n===`dashed`)}return{link:i,place:a,applyVisual:o}}var ut=`/* The whole shadow-UI stylesheet: windows, overlay, progress bar, notice toast,
   link highlight, reader/error bodies. Imported with \`?raw\` by preview/index.ts
   (as PREVIEW_STYLE) and injected into \`createShadowRootUi\` by content.ts,
   concatenated with SELECTION_STYLE.

   It must stay a string at runtime: shadow DOM does not inherit page styles, so
   a plain CSS import would be extracted into the manifest's content_scripts.css
   — invisible to the shadow root and leaking into the host page. */
:host {
  all: initial;
  /* Window surface tokens. The app theme sets the defaults; a window theme
     preset overrides them per window (inline, so it always wins). */
  --tp-base: #fff;
  --tp-ink: #1f2328;
  --tp-surface: #fff;
  --tp-head-height: 30px;
  --tp-line: color-mix(in srgb, var(--tp-ink) 12%, transparent);
  --tp-soft: color-mix(in srgb, var(--tp-ink) 7%, var(--tp-surface));
}

:host([data-tp-theme='dark']) {
  --tp-base: #1e2126;
  --tp-ink: #e6e8eb;
  --tp-surface: #1e2126;
}

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: system-ui, -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
}

.tp-overlay {
  position: fixed;
  inset: 0;
  z-index: 2147483640;
  pointer-events: none;
  backdrop-filter: blur(var(--tp-blur, 0px));
  background: rgba(0, 0, 0, var(--tp-dim, 0));
  opacity: 0;
  transition: opacity .2s linear;
}

.tp-overlay.tp-on {
  opacity: 1;
}

.tp-win {
  position: fixed;
  z-index: 2147483641;
  display: flex;
  flex-direction: column;
  width: var(--tp-w, 40%);
  height: var(--tp-h, 55%);
  color: var(--tp-ink);
  border-radius: 14px;
  overflow: hidden;
  /* No background on the root: the opaque surface lives on .tp-body, which
     reserves the bar's height with padding-top. overflow: hidden still clips
     both to the rounded corners. */
  background: none;
  /* Glass fill opacity of the title bar. Over an iframe there is nothing beneath
     it (body's padding-top keeps that content below the bar), so the strip just
     reads as surface; over the reader/translation panes live text does pass
     under and shows through. Power saving raises it to 100%. Declared here (not
     on :host) because the fill mixes with this window's own --tp-surface, which
     a window theme preset overrides inline. */
  --tp-glass: 72%;
  border: 1px solid var(--tp-line);
  box-shadow: 0 12px 40px rgba(0, 0, 0, .22), 0 2px 8px rgba(0, 0, 0, .12);
  /* Tencent console dialog motion (TDesign's tokens): a 200ms decelerating
     entrance zooming up from 92%, and a shorter accelerated exit. The resting
     state is .tp-in with transform back at none — a value left on the element
     would keep it a promoted layer and a containing block for no reason once
     the animation is done. */
  --tp-in-motion: .2s cubic-bezier(0, 0, .15, 1);
  --tp-out-motion: .16s cubic-bezier(.38, 0, .24, 1);
  /* Origin is set per window in place(): the window grows out of the link. */
  transform-origin: 50% 50%;
  opacity: 0;
  transform: scale(.92);
  transition: opacity var(--tp-in-motion), transform var(--tp-in-motion);
}

.tp-win.tp-in {
  opacity: 1;
  transform: none;
}

/* The root takes programmatic focus only to route Escape (tabindex="-1"),
   never via the keyboard, so it must never render a focus ring. */
.tp-win:focus {
  outline: none;
}

.tp-win.tp-out {
  opacity: 0;
  transform: scale(.96);
  pointer-events: none;
  transition: opacity var(--tp-out-motion), transform var(--tp-out-motion);
}

.tp-win.tp-sidebar {
  border-radius: 0;
  height: 100vh;
}

/* Title bar across the top of the window. Absolute and out of flow, paired with
   the same --tp-head-height reserved as .tp-body's padding-top: the iframe (the
   only in-flow child there) starts *below* the bar, so a framed page is never
   partly covered by chrome. The four panes are position:absolute;inset:0 against
   .tp-body's padding box, so they do span the strip and glide under the glass —
   which is where the backdrop has anything real to sample. It has to be
   absolute: back in flow plus that padding would push content down twice the
   bar, and z-index has to beat those panes. Title group on the left (it is also
   the drag handle), pin + actions flush right. */
.tp-head {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  z-index: 3;
  display: flex;
  align-items: stretch;
  height: var(--tp-head-height);
  /* Stacked glass: a top sheen fading into a bottom shade (both mixed toward
     transparent so they read in light and dark alike), a faint accent tint,
     and the surface fill — over a blur of whatever .tp-body paints under it. The
     inset light line on the top edge gives the glass its thickness. */
  background:
    linear-gradient(180deg,
      color-mix(in srgb, #fff 30%, transparent),
      color-mix(in srgb, #fff 6%, transparent) 45%,
      transparent 62%,
      color-mix(in srgb, var(--tp-ink) 8%, transparent)),
    linear-gradient(180deg, color-mix(in srgb, var(--tp-accent, #4f6bf6) 10%, transparent), transparent 55%),
    color-mix(in srgb, var(--tp-surface) var(--tp-glass), transparent);
  backdrop-filter: blur(16px) saturate(1.5);
  border-bottom: 1px solid var(--tp-line);
  box-shadow: inset 0 1px 0 color-mix(in srgb, #fff 35%, transparent);
  user-select: none;
}

/* Power saving drops the backdrop sampling (blurring is exactly the GPU cost the
   user asked to avoid) and makes the fill opaque. Engines without backdrop
   sampling get the same fallback. */
.tp-win.tp-nofrost .tp-head {
  --tp-glass: 100%;
  backdrop-filter: none;
}

@supports not (backdrop-filter: blur(2px)) {
  .tp-head {
    --tp-glass: 100%;
    backdrop-filter: none;
  }
}

/* The title group fills the leftover space and is the drag handle, so presses
   anywhere on the empty bar move the window instead of falling through. */
.tp-head-info {
  flex: 1;
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 0 4px 0 12px;
  overflow: hidden;
}

/* Right cluster: the pin alone, then reload / open / close. The groups carry no
   padding of their own so the buttons can run the full height of the bar. */
.tp-head-pin {
  flex: none;
  display: flex;
  align-items: stretch;
}

.tp-head-actions {
  flex: none;
  display: flex;
  align-items: stretch;
}

.tp-favicon {
  width: 16px;
  height: 16px;
  flex: none;
  border-radius: 3px;
}

.tp-favicon.tp-hide {
  display: none;
}

.tp-title {
  flex: 1;
  min-width: 0;
  font-size: 10px;
  opacity: .8;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.tp-badge {
  display: none;
  flex: none;
  font-size: 11px;
  line-height: 1;
  padding: 3px 7px;
  border-radius: 999px;
  background: color-mix(in srgb, var(--tp-accent, #4f6bf6) 14%, #fff);
  color: var(--tp-accent, #4f6bf6);
}

.tp-badge.tp-show {
  display: inline-block;
}

.tp-risk {
  background: color-mix(in srgb, #f59e0b 24%, var(--tp-surface));
  color: color-mix(in srgb, #b45309 78%, var(--tp-ink));
  cursor: help;
}

/* Flat title-bar buttons: slim full-height zones with no resting fill, like a
   native window control. The bar's own rounded corners clip the outermost
   one, so the group reads as part of the chrome rather than floating chips. */
.tp-btn {
  flex: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 26px;
  height: 100%;
  border: 0;
  border-radius: 0;
  background: transparent;
  color: color-mix(in srgb, var(--tp-ink) 72%, transparent);
  cursor: pointer;
  transition: background .12s ease, color .12s ease;
}

/* Every header button is the same thin-stroke icon, so the bar reads as one set
   (mixing SVG with font glyphs put two weights and two baselines side by side). */
.tp-btn svg {
  width: 13px;
  height: 13px;
  display: block;
}

.tp-btn:hover {
  background: color-mix(in srgb, var(--tp-ink) 9%, transparent);
  color: var(--tp-ink);
}

/* The close control reads as destructive on hover, the way every native title
   bar does. */
.tp-btn[data-act='close']:hover {
  background: #e81123;
  color: #fff;
}

.tp-pin svg {
  transform: rotate(45deg);
  transition: transform .15s ease;
}

/* A pinned window keeps its control lit so the state is readable at a glance. */
.tp-pin.tp-on {
  background: color-mix(in srgb, var(--tp-accent, #4f6bf6) 16%, transparent);
  color: var(--tp-accent, #4f6bf6);
}

.tp-pin.tp-on svg {
  transform: rotate(0deg);
}

.tp-resize {
  position: absolute;
  right: 0;
  bottom: 0;
  width: 16px;
  height: 16px;
  cursor: nwse-resize;
  opacity: .45;
  transition: opacity .15s ease;
  background: linear-gradient(135deg, transparent 46%, #8c959f 46%, #8c959f 56%, transparent 56%,
      transparent 68%, #8c959f 68%, #8c959f 78%, transparent 78%);
}

.tp-resize:hover {
  opacity: .9;
}

.tp-win.tp-sidebar .tp-resize {
  display: none;
}

.tp-win.tp-resizing {
  user-select: none;
}

.tp-body {
  position: relative;
  flex: 1;
  min-height: 0;
  background: var(--tp-surface);
  padding-top: var(--tp-head-height);
}

.tp-body>iframe {
  width: 100%;
  height: 100%;
  border: 0;
  display: block;
}

.tp-skeleton {
  position: absolute;
  inset: 0;
  /* Pane paddings below are measured from the top of the window, not from the
     bar: inset: 0 resolves against .tp-body's padding box, so body's own
     padding-top does not shift this element. Keep each top value at
     --tp-head-height + 10–16px of clearance, and change the four together with
     the token. Here: 30 + 14. */
  padding: 44px 18px 18px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.tp-skeleton i {
  display: block;
  height: 14px;
  border-radius: 6px;
  background: linear-gradient(90deg, var(--tp-soft) 25%, color-mix(in srgb, var(--tp-surface) 70%, var(--tp-soft)) 50%, var(--tp-soft) 75%);
  background-size: 200% 100%;
  animation: tp-shimmer 1.2s infinite;
}

.tp-skeleton i:first-child {
  height: 22px;
  width: 60%;
}

.tp-skeleton i:nth-child(2) {
  width: 90%;
}

.tp-skeleton i:nth-child(3) {
  width: 80%;
}

.tp-skeleton i:nth-child(4) {
  width: 85%;
}

@keyframes tp-shimmer {
  to {
    background-position: -200% 0;
  }
}

/* Scrolling the reader must never chain to the page behind the window: at its
   bounds the wheel gesture stops here (see the root's wheel handler for the
   non-scrollable parts of the window). */
.tp-reader {
  position: absolute;
  inset: 0;
  overflow: auto;
  overscroll-behavior: contain;
  /* 30 + 16: the article title starts clear of the bar at scroll-top, and later
     text glides under the glass (this pane spans the strip). */
  padding: 46px 26px 22px;
  font-size: 15px;
  line-height: 1.75;
  color: #24292f;
}

.tp-reader h1.tp-r-title {
  font-size: 21px;
  line-height: 1.4;
  margin-bottom: 14px;
}

.tp-reader p {
  margin: 0 0 12px;
}

.tp-reader img {
  max-width: 100%;
  height: auto;
  border-radius: 8px;
  margin: 6px 0;
}

.tp-reader h2,
.tp-reader h3,
.tp-reader h4 {
  margin: 18px 0 8px;
  line-height: 1.45;
}

.tp-reader ul,
.tp-reader ol {
  margin: 0 0 12px 22px;
}

.tp-reader a {
  color: var(--tp-accent, #4f6bf6);
  text-decoration: none;
}

.tp-reader a:hover {
  text-decoration: underline;
}

.tp-reader pre {
  background: var(--tp-soft);
  padding: 10px 12px;
  border-radius: 8px;
  overflow: auto;
  margin-bottom: 12px;
}

.tp-error {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 10px;
  text-align: center;
  /* 30 + 10: clears the bar even in a short window. */
  padding: 40px 24px 24px;
  font-size: 13px;
  color: color-mix(in srgb, var(--tp-ink) 62%, transparent);
}

.tp-error button {
  border: 0;
  border-radius: 8px;
  padding: 8px 14px;
  background: var(--tp-accent, #4f6bf6);
  color: #fff;
  font-size: 13px;
  cursor: pointer;
}

/* ---------- inline translation card ---------- */
/* An engine whose page refuses to be framed (Google) but exposes a CORS-open
   JSON endpoint: we render the result ourselves, so this is the window's
   content — not an error and not a reader view. Two stacked blocks, source
   first, so it reads like the translator's own UI. */
.tp-trans {
  position: absolute;
  inset: 0;
  overflow: auto;
  overscroll-behavior: contain;
  /* 30 + 14, the same clearance .tp-skeleton uses. */
  padding: 44px 22px 22px;
  font-size: 14px;
  line-height: 1.7;
  color: var(--tp-ink);
}

.tp-trans-src {
  color: color-mix(in srgb, var(--tp-ink) 62%, transparent);
  font-size: 13px;
  padding-bottom: 14px;
  margin-bottom: 14px;
  border-bottom: 1px solid var(--tp-line);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

.tp-trans-dst {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

/* The detected source language, and the escape hatch to the real site. */
.tp-trans-meta {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-top: 18px;
  font-size: 12px;
  color: color-mix(in srgb, var(--tp-ink) 52%, transparent);
}

.tp-trans-meta button {
  border: 0;
  border-radius: 999px;
  padding: 4px 10px;
  background: color-mix(in srgb, var(--tp-accent, #4f6bf6) 12%, transparent);
  color: var(--tp-accent, #4f6bf6);
  font-size: 12px;
  cursor: pointer;
}

.tp-trans-meta button:hover {
  background: color-mix(in srgb, var(--tp-accent, #4f6bf6) 22%, transparent);
}

/* ---------- dark appearance ---------- */
/* The resolved theme is written to the shadow host as data-tp-theme (see
   content.ts), so both this file's UI and the selection toolbar follow it. */
:host([data-tp-theme='dark']) {
  color-scheme: dark;
}

:host([data-tp-theme='dark']) .tp-notice {
  background: #e6e8eb;
  color: #15171a;
}

.tp-progress {
  position: fixed;
  z-index: 2147483647;
  display: none;
  width: 72px;
  height: 6px;
  border-radius: 999px;
  overflow: hidden;
  background: rgba(255, 255, 255, .92);
  border: 1px solid rgba(0, 0, 0, .08);
  box-shadow: 0 2px 10px rgba(0, 0, 0, .28);
  /* Never hit-tested: while a hover counts down the bar sits next to the
     pointer, and swallowing pointerover would cancel the hover itself. */
  pointer-events: none;
}

.tp-progress.tp-show {
  display: block;
}

.tp-progress-fill {
  height: 100%;
  width: 0;
  border-radius: inherit;
  background: var(--tp-accent, #4f6bf6);
}

.tp-notice {
  position: fixed;
  z-index: 2147483647;
  display: none;
  max-width: 300px;
  padding: 7px 11px;
  border-radius: 9px;
  background: #1f2328;
  color: #fff;
  font-size: 12px;
  line-height: 1.45;
  box-shadow: 0 8px 26px rgba(0, 0, 0, .32);
  /* Same reason as the progress bar: it must never swallow pointer events. */
  pointer-events: none;
}

.tp-notice.tp-show {
  display: block;
}

.tp-hl {
  position: fixed;
  z-index: 2147483640;
  opacity: 0;
  transition: opacity .12s ease;
  /* Width/radius are user settings (--tp-hlw / --tp-hlr, written by the
     widget's applyVisual); the fallbacks match DEFAULT_SETTINGS. */
  border: var(--tp-hlw, 2px) solid var(--tp-accent, #4f6bf6);
  border-radius: var(--tp-hlr, 4px);
  background: color-mix(in srgb, var(--tp-accent, #4f6bf6) 12%, transparent);
  box-shadow: 0 0 0 2px color-mix(in srgb, var(--tp-accent, #4f6bf6) 22%, transparent);
  /* Never hit-tested: it sits exactly on the hovered link. */
  pointer-events: none;
}

.tp-hl.tp-dashed {
  border-style: dashed;
}

.tp-hl.tp-show {
  opacity: 1;
}

/* ---------- reduced motion ---------- */
/* Set by content.ts (data-tp-motion) from the settings plus the OS preference.
   Every transition in here is decorative, so one attribute kills them all; the
   countdown bar's fill transition is armed in JS instead (see startProgress). */
:host([data-tp-motion]) .tp-overlay,
:host([data-tp-motion]) .tp-win,
:host([data-tp-motion]) .tp-hl,
:host([data-tp-motion]) .tp-btn,
:host([data-tp-motion]) .tp-pin svg,
:host([data-tp-motion]) .tp-resize {
  transition: none;
}

:host([data-tp-motion]) .tp-skeleton i {
  animation: none;
}`;function dt(e,t){let n=document.createElement(`div`);n.className=`tp-overlay`,t.appendChild(n);let r=st(t,{getAccent:()=>S(u()),reduceMotion:()=>e.getPower().reduceMotion}),i=ct(t,e.i18n),a=lt(t),o=[],s=1,c=2147483641,l={};pe.getValue().then(e=>{e&&(l=e)});function u(){return $(e.getSettings())}function d(){return e.getPower().reduceMotion?0:160}function f(){return e.getPower().level===`off`?u().blurStrength:0}function p(){return e.getPower().level!==`off`}function m(){let e=u();return e.sizeUnit===`px`?{w:e.widthPx,h:e.heightPx}:{w:Math.round(innerWidth*e.width/100),h:Math.round(innerHeight*e.height/100)}}function h(e,t){return`${t}${e.sizeUnit===`px`?`px`:`%`}`}function g(e){return e.manualSize??m()}function _(e){let t=u().position;return e.sidebar===!0?`sidebar`:e.sidebar===!1&&t===`sidebar`?`center`:t}function v(){return location.hostname}function y(e){let t=l[v()];if(!t)return;let n=Math.max(240,Math.min(t.w,innerWidth-16)),r=Math.max(160,Math.min(t.h,innerHeight-16)),i=Math.min(Math.max(0,t.x),Math.max(0,innerWidth-n)),a=Math.min(Math.max(0,t.y),Math.max(0,innerHeight-r));e.manualSize={w:n,h:r},e.manualPosition=!0,e.root.classList.remove(`tp-sidebar`),e.root.style.left=`${i}px`,e.root.style.top=`${a}px`,e.root.style.right=`auto`,e.root.style.width=`${n}px`,e.root.style.height=`${r}px`;let{x:o,y:s}=e.lastPointer;e.root.style.transformOrigin=`${ft(o-i,n)}% ${ft(s-a,r)}%`}function b(e){if(!u().rememberWindowGeom||_(e)===`sidebar`)return;let t=e.root,n={x:Math.round(t.offsetLeft),y:Math.round(t.offsetTop),w:e.manualSize?.w??t.offsetWidth,h:e.manualSize?.h??t.offsetHeight};(async()=>{let e=me(await pe.getValue(),v(),n);l=e,await pe.setValue(e)})().catch(()=>{})}function x(e){return ae.find(t=>t.id===e.windowTheme)??ae[0]}function S(e,t){let n=x(e);return n.id===`auto`?t?.autoAccent??w(e,t):n.id===`custom`?e.windowColor:n.accent}function C(e){if(e.closed)return null;let t=e.iframe;if(t)try{let e=t.contentDocument;if(e?.body)return e}catch{}let n=e.fetchResult?.html;if(!n)return null;try{return new DOMParser().parseFromString(n,`text/html`)}catch{return null}}function w(e,t){if(!t)return Qe()??e.windowColor;if(t.autoAccent===void 0){let e=C(t);t.autoAccent=(e?Ze(e):null)??Qe()}return t.autoAccent??e.windowColor}function T(e,t,n){if(e.style.setProperty(`--tp-accent`,n),t.kind===`dark`){e.style.setProperty(`--tp-surface`,t.surface??`#1e2432`),e.style.setProperty(`--tp-ink`,t.ink??`#e7eaf0`);return}e.style.setProperty(`--tp-surface`,`color-mix(in srgb, var(--tp-accent) 7%, var(--tp-base))`),e.style.removeProperty(`--tp-ink`)}function E(){let e=u(),t=Math.min(100,Math.max(0,f()))/100;n.style.setProperty(`--tp-blur`,`${(t*14).toFixed(2)}px`),n.style.setProperty(`--tp-dim`,`${(t*et).toFixed(3)}`),n.style.setProperty(`--tp-accent`,e.themeColor);let i=S(e);a.applyVisual(i,e.highlightStyle,e.highlightWidth,e.highlightRadius),r.setAccent(i);for(let t of o)T(t.root,x(e),S(e,t)),t.root.style.setProperty(`--tp-w`,h(e,e.sizeUnit===`px`?e.widthPx:e.width)),t.root.style.setProperty(`--tp-h`,h(e,e.sizeUnit===`px`?e.heightPx:e.height)),t.root.classList.toggle(`tp-nofrost`,p())}function D(e){return o.filter(e=>!e.closed).indexOf(e)}function O(e){if(e.manualPosition)return;let t=u(),n=innerWidth,r=innerHeight,i=D(e),a=_(e);if(e.root.classList.toggle(`tp-sidebar`,a===`sidebar`),a===`sidebar`){e.manualSize=void 0,e.root.style.removeProperty(`width`),e.root.style.removeProperty(`height`);let n=i*m().w;e.root.style.top=`0px`,e.root.style.left=`auto`,t.sidebarSide===`right`?(e.root.style.right=`${n}px`,e.root.style.transformOrigin=`100% 50%`):(e.root.style.right=`auto`,e.root.style.left=`${n}px`,e.root.style.transformOrigin=`0% 50%`);return}let o=i*26,{w:s,h:c}=g(e),l,d;switch(a){case`top-left`:l=16,d=16;break;case`top-right`:l=n-s-16,d=16;break;case`bottom-left`:l=16,d=r-c-16;break;case`center`:l=(n-s)/2,d=(r-c)/2;break;case`top`:l=(n-s)/2,d=8;break;case`bottom`:l=(n-s)/2,d=r-c-8;break;case`left`:l=16,d=(r-c)/2;break;case`right`:l=n-s-16,d=(r-c)/2;break;default:l=n-s-16,d=r-c-16}l+=o,d+=o,l=Math.min(Math.max(8,l),Math.max(8,n-s-8)),d=Math.min(Math.max(0,d),Math.max(0,r-c)),e.root.style.left=`${l}px`,e.root.style.top=`${d}px`,e.root.style.right=`auto`;let{x:f,y:p}=e.lastPointer;e.root.style.transformOrigin=`${ft(f-l,s)}% ${ft(p-d,c)}%`}function k(e){return o.find(t=>!t.closed&&t.url===e)}function A(e){e?.closeTimer&&(clearTimeout(e.closeTimer),e.closeTimer=void 0)}function j(e){A(k(e))}function ee(e,t){e.pinned=t,t&&A(e),M(e)}function M(t){if(t.pinBtnEl.classList.toggle(`tp-on`,t.pinned),t.pinBtnEl.setAttribute(`aria-pressed`,String(t.pinned)),t.pinBtnEl.title=e.i18n.t(t.pinned?`preview.unpin`:`preview.pin`),t.reloadBtnEl.title=e.i18n.t(`preview.reload`),t.openBtnEl.title=e.i18n.t(`preview.openTab`),t.closeBtnEl.title=e.i18n.t(u().closeOnEscape?`preview.closeEsc`:`preview.close`),t.readerBadge.classList.contains(`tp-show`)&&(t.readerBadge.textContent=e.i18n.t(`preview.readerBadge`)),t.risk){let n=`⚠ ${e.i18n.t(`risk.${t.risk}`)}`;t.riskBadge.textContent=n,t.riskBadge.title=n,t.riskBadge.classList.add(`tp-show`)}}function P(e){if(u().closeOnMouseLeave)for(let t of o)t.closed||t.url===e||t.pinned||(A(t),t.closeTimer=setTimeout(()=>L(t),400))}function F(){for(let e of[...o])!e.closed&&!e.pinned&&L(e)}function I(){let e;for(let t of o)t.closed||t.pinned||(!e||Number(t.root.style.zIndex||0)>=Number(e.root.style.zIndex||0))&&(e=t);return e}function L(e,t=!0){if(e.closed)return;e.closed=!0,A(e),e.loadTimer&&clearTimeout(e.loadTimer);let n=o.indexOf(e);n>=0&&o.splice(n,1);for(let e of o)e.manualPosition||O(e);if(R(),!t){e.iframe?.setAttribute(`src`,`about:blank`),e.root.remove();return}e.root.classList.remove(`tp-in`),e.root.classList.add(`tp-out`),e.fadeTimer=setTimeout(()=>{e.iframe?.setAttribute(`src`,`about:blank`),e.root.remove()},d()+40)}function R(){let e=f()>0&&o.some(e=>!e.closed&&e.hovered);n.classList.toggle(`tp-on`,e)}function z(){let e=document.createElement(`div`);return e.className=`tp-skeleton`,e.append(...[0,1,2,3].map(()=>document.createElement(`i`))),e}function B(e,t){e.body.innerHTML=``,e.body.appendChild(t)}function V(t){let n=t.body.querySelector(`.tp-reader, .tp-trans`);n&&n.scrollTo({top:0,behavior:e.getPower().reduceMotion?`auto`:`smooth`})}function H(e){let t=document.createElement(`iframe`);t.src=e.url,t.referrerPolicy=`no-referrer-when-downgrade`,e.iframe=t,B(e,t),e.loadTimer=setTimeout(()=>{e.loadTimer=void 0,W(e)},$e),t.addEventListener(`load`,()=>{e.loadTimer&&=(clearTimeout(e.loadTimer),void 0),U(e)})}function U(e){let t=u();if(x(t).id!==`auto`)return;let n=C(e);e.autoAccent=(n?Ze(n):null)??Qe()??null,T(e.root,x(t),S(t,e))}function W(t){if(t.translate)return G(t);let n=t.fetchResult;if(!n?.html)return G(t);let r=Ee(n.html,n.finalUrl??t.url);if(!r)return G(t);B(t,De(r,e.i18n,t.url)),t.readerBadge.textContent=e.i18n.t(`preview.readerBadge`),t.readerBadge.classList.add(`tp-show`),t.iframe=void 0,U(t)}function G(t,n=`preview.failed`){let r=document.createElement(`div`);r.className=`tp-error`;let i=document.createElement(`span`);i.textContent=e.i18n.t(n);let a=document.createElement(`button`);a.textContent=e.i18n.t(`preview.openTab`),a.addEventListener(`click`,()=>{N.runtime.sendMessage({type:`prelook:openTab`,url:t.url}),L(t)}),r.append(i,a),B(t,r)}function te(e){try{let t=N.i18n.getUILanguage(),n=new Intl.DisplayNames([t],{type:`language`}).of(e);if(n&&n.toLowerCase()!==e.toLowerCase())return n}catch{}return e}function ne(t,n,r,i){let a=document.createElement(`div`);a.className=`tp-trans`;let o=document.createElement(`div`);o.className=`tp-trans-src`,o.textContent=n;let s=document.createElement(`div`);s.className=`tp-trans-dst`,s.textContent=r;let c=document.createElement(`div`);if(c.className=`tp-trans-meta`,i){let t=document.createElement(`span`);t.textContent=e.i18n.t(`translate.detected`,{lang:te(i)}),c.append(t)}let l=document.createElement(`button`);l.textContent=e.i18n.t(`preview.openTab`),l.addEventListener(`click`,()=>{N.runtime.sendMessage({type:`prelook:openTab`,url:t.url})}),c.append(l),a.append(o,s,c),B(t,a),t.iframe=void 0,U(t)}async function re(e,t){let n;try{n=await N.runtime.sendMessage({type:`prelook:translate`,text:t.text,to:t.to})}catch{n=void 0}if(!e.closed){if(!n?.ok||!n.translated){G(e,`translate.failed`);return}ne(e,t.text,n.translated,n.sourceLang)}}async function ie(t){if(t.inlineTranslate){await re(t,t.inlineTranslate);return}if(e.getPower().level===`max`){H(t);return}let n;try{n=await N.runtime.sendMessage({type:`prelook:fetch`,url:t.url})}catch{n=void 0}if(!t.closed){if(t.fetchResult=n,n?.title&&(t.titleEl.textContent=n.title),n?.favicon&&(t.faviconEl.src=n.favicon,t.faviconEl.classList.remove(`tp-hide`),t.faviconEl.onerror=()=>t.faviconEl.classList.add(`tp-hide`)),(n?.title||n?.favicon)&&u().historyEnabled&&fe(t.url,n.title,n.favicon),n?.html&&U(t),n&&!n.canEmbed){t.translate?G(t,`preview.embedBlocked`):n.html?W(t):G(t);return}H(t)}}function K(){for(let e of o)M(e)}function oe(n){let r=k(n.url);if(r){n.sidebar!==void 0&&(r.sidebar=n.sidebar),r.manualPosition=!1,r.lastPointer=n.pointer,u().rememberWindowGeom&&_(r)!==`sidebar`&&y(r),O(r),r.root.style.zIndex=String(++c),j(n.url);return}let a=Math.max(1,e.getMaxWindows());for(;o.filter(e=>!e.closed).length>=a;){let e=o.find(e=>!e.closed&&!e.pinned);if(!e){i.show(`preview.pinLimit`,n.pointer.x,n.pointer.y,{max:a});return}L(e)}let l=u(),d=document.createElement(`div`);d.className=`tp-win`,d.tabIndex=-1,d.style.zIndex=String(++c),T(d,x(l),S(l)),d.style.setProperty(`--tp-w`,h(l,l.sizeUnit===`px`?l.widthPx:l.width)),d.style.setProperty(`--tp-h`,h(l,l.sizeUnit===`px`?l.heightPx:l.height)),d.classList.toggle(`tp-nofrost`,p());let f=document.createElement(`div`);f.className=`tp-head`;let m=document.createElement(`div`);m.className=`tp-head-info`;let g=document.createElement(`div`);g.className=`tp-head-pin`;let v=document.createElement(`div`);v.className=`tp-head-actions`;let C=document.createElement(`img`);C.className=`tp-favicon tp-hide`,C.alt=``;let w=document.createElement(`span`);w.className=`tp-title`,w.textContent=pt(n.url);let E=document.createElement(`span`);E.className=`tp-badge tp-risk`;let D=document.createElement(`span`);D.className=`tp-badge`;let A=document.createElement(`button`);A.className=`tp-btn tp-pin`,A.dataset.act=`pin`,A.type=`button`,A.innerHTML=rt;let F=document.createElement(`button`);F.className=`tp-btn`,F.dataset.act=`reload`,F.type=`button`,F.innerHTML=it;let I=document.createElement(`button`);I.className=`tp-btn`,I.dataset.act=`open`,I.type=`button`,I.innerHTML=at;let H=document.createElement(`button`);H.className=`tp-btn`,H.dataset.act=`close`,H.type=`button`,H.innerHTML=ot,m.append(C,w,E,D),g.append(A),v.append(F,I,H),f.append(m,g,v);let U=document.createElement(`div`);U.className=`tp-resize`;let W=document.createElement(`div`);W.className=`tp-body`,W.appendChild(z()),d.append(f,W,U);let G={id:s++,url:n.url,root:d,body:W,titleEl:w,faviconEl:C,readerBadge:D,riskBadge:E,headEl:f,closed:!1,manualPosition:!1,sidebar:n.sidebar,translate:n.translate===!0,inlineTranslate:n.inlineTranslate,hovered:!1,risk:n.risk,autoAccent:void 0,pinned:u().autoPin,pinBtnEl:A,reloadBtnEl:F,openBtnEl:I,closeBtnEl:H,lastPointer:n.pointer};if(M(G),d.addEventListener(`wheel`,e=>{e.target?.closest?.(`.tp-reader`)||e.preventDefault()},{passive:!1}),d.addEventListener(`mousedown`,()=>{d.style.zIndex=String(++c),d.focus()}),d.addEventListener(`mouseover`,()=>{G.hovered=!0,R(),j(n.url)}),d.addEventListener(`mouseout`,e=>{let t=e.relatedTarget;(!t||!d.contains(t))&&(G.hovered=!1,R(),P(null))}),f.addEventListener(`click`,e=>{let t=e.target.closest?.(`[data-act]`);t&&(t.dataset.act===`close`?L(G):t.dataset.act===`pin`?ee(G,!G.pinned):t.dataset.act===`reload`?(G.loadTimer&&=(clearTimeout(G.loadTimer),void 0),B(G,z()),ie(G)):t.dataset.act===`open`&&(N.runtime.sendMessage({type:`prelook:openTab`,url:G.url}),L(G)))}),f.addEventListener(`dblclick`,e=>{e.target.closest?.(`[data-act]`)||V(G)}),_(G)!==`sidebar`){let e=0,t=0,n=0,r=0,i=!1;m.style.cursor=`grab`,m.addEventListener(`pointerdown`,a=>{i=!0,e=a.clientX,t=a.clientY;let o=d.getBoundingClientRect();n=o.left,r=o.top,m.setPointerCapture(a.pointerId)}),m.addEventListener(`pointermove`,a=>{i&&(G.manualPosition=!0,d.style.left=`${Math.max(0,n+a.clientX-e)}px`,d.style.top=`${Math.max(0,r+a.clientY-t)}px`,d.style.right=`auto`)}),m.addEventListener(`pointerup`,()=>{i&&(i=!1,G.manualPosition&&b(G))});let a=0,o=0,s=0,c=0,l=!1;U.addEventListener(`pointerdown`,e=>{e.preventDefault(),e.stopPropagation(),l=!0,a=e.clientX,o=e.clientY,s=d.offsetWidth,c=d.offsetHeight,d.classList.add(`tp-resizing`),U.setPointerCapture?.(e.pointerId)}),U.addEventListener(`pointermove`,e=>{if(!l)return;let t=Math.round(Math.min(Math.max(240,s+e.clientX-a),innerWidth-16)),n=Math.round(Math.min(Math.max(160,c+e.clientY-o),innerHeight-16));G.manualSize={w:t,h:n},d.style.width=`${t}px`,d.style.height=`${n}px`});let u=e=>{l&&(l=!1,d.classList.remove(`tp-resizing`),U.releasePointerCapture?.(e.pointerId),b(G))};U.addEventListener(`pointerup`,u),U.addEventListener(`pointercancel`,u)}t.appendChild(d),o.push(G),l.rememberWindowGeom&&_(G)!==`sidebar`&&y(G),O(G),R(),l.historyEnabled&&de({url:n.url,title:pt(n.url),time:Date.now()}),requestAnimationFrame(()=>{requestAnimationFrame(()=>d.classList.add(`tp-in`))}),ie(G)}function q(e){E(),R(),e.highlightLinks||a.link(null);for(let t of o)t.manualPosition=!1,e.rememberWindowGeom&&_(t)!==`sidebar`&&y(t),O(t);K()}function se(){E(),R(),e.getPower().level===`max`&&a.link(null)}function ce(){for(let e of o)e.manualPosition||O(e);a.place()}function J(){a.place(),u().closeOnScroll&&F()}window.addEventListener(`resize`,ce),window.addEventListener(`scroll`,J,{capture:!0,passive:!0});function Y(e){if(e.key!==`Escape`||e.repeat||!u().closeOnEscape)return;let t=I();t&&(e.preventDefault(),L(t))}window.addEventListener(`keydown`,Y,!0);function le(){window.removeEventListener(`resize`,ce),window.removeEventListener(`scroll`,J,{capture:!0}),window.removeEventListener(`keydown`,Y,!0),i.clear();for(let e of[...o])e.fadeTimer&&clearTimeout(e.fadeTimer),L(e,!1)}function ue(e){a.link(e&&u().highlightLinks?e:null)}return E(),{open:oe,keep:j,releaseExcept:P,startProgress:(e,t,n)=>r.start(e,t,n),cancelProgress:()=>r.cancel(),highlightLink:ue,dismissUnpinned:F,notice:(e,t,n,r)=>i.show(e,t,n,r),applySettings:q,applyPower:se,destroy:le}}function ft(e,t){return Math.min(100,Math.max(0,e/t*100))}function pt(e){try{return new URL(e).hostname}catch{return e}}var mt=[{token:`paypal`,domain:`paypal.com`},{token:`apple`,domain:`apple.com`},{token:`icloud`,domain:`icloud.com`},{token:`google`,domain:`google.com`},{token:`gmail`,domain:`google.com`},{token:`microsoft`,domain:`microsoft.com`},{token:`outlook`,domain:`live.com`},{token:`office`,domain:`office.com`},{token:`amazon`,domain:`amazon.com`},{token:`netflix`,domain:`netflix.com`},{token:`facebook`,domain:`facebook.com`},{token:`instagram`,domain:`instagram.com`},{token:`whatsapp`,domain:`whatsapp.com`},{token:`telegram`,domain:`telegram.org`},{token:`alipay`,domain:`alipay.com`},{token:`taobao`,domain:`taobao.com`},{token:`wechat`,domain:`weixin.qq.com`},{token:`weixin`,domain:`weixin.qq.com`},{token:`binance`,domain:`binance.com`},{token:`coinbase`,domain:`coinbase.com`},{token:`metamask`,domain:`metamask.io`},{token:`dropbox`,domain:`dropbox.com`},{token:`steam`,domain:`steampowered.com`}],ht=[`com.cn`,`net.cn`,`org.cn`,`gov.cn`,`edu.cn`,`co.uk`,`org.uk`,`ac.uk`,`gov.uk`,`com.au`,`net.au`,`co.jp`,`co.kr`,`com.tw`,`com.hk`,`com.sg`,`com.br`],gt=new Set([`bit.ly`,`t.co`,`tinyurl.com`,`goo.gl`,`is.gd`,`ow.ly`,`buff.ly`,`rebrand.ly`,`cutt.ly`,`shorturl.at`,`rb.gy`,`t.ly`,`su.pr`,`v.gd`,`sourl.cn`,`url.cn`,`3.cn`,`dwz.cn`,`mrw.so`]),_t=[`login`,`signin`,`verify`,`secure`,`account`,`wallet`,`support`,`update`],vt=/\b((?:[a-z0-9-]+\.)+(?:com|cn|net|org|io|co|me|app|dev|xyz|top|info|biz|ru|uk|de|jp|kr|tk|cc))\b/i;function yt(e){return e.split(`.`).filter(Boolean)}function bt(e){let t=yt(e);if(t.length<=2)return t.join(`.`);let n=t.slice(-2).join(`.`);return ht.includes(n)?t.slice(-3).join(`.`):n}function xt(e){return e.hostname.toLowerCase().replace(/\.$/,``)}function St(e){return e.startsWith(`[`)?!0:/^\d{1,3}(\.\d{1,3}){3}$/.test(e)}function Ct(e,t){let n;try{n=new URL(e)}catch{return null}if(n.protocol!==`http:`&&n.protocol!==`https:`)return null;if(n.username||n.password)return{reason:`userinfo`};let r=xt(n),i=bt(r);if(St(r))return{reason:`ipHost`};if(r.includes(`xn--`)||/[^\u0000-\u007f]/.test(r))return{reason:`punycode`};if(gt.has(i)||gt.has(r))return{reason:`shortener`};let a=r.replace(/[^a-z0-9]/g,``);for(let e of mt)if(a.includes(e.token)&&!(i===e.domain||i.endsWith(`.${e.domain}`))&&!e.domain.endsWith(`.${i}`))return{reason:`brandMismatch`};if(yt(r).some(e=>_t.some(t=>e.includes(t)))){let e=t.toLowerCase();if(mt.some(t=>e.includes(t.token)))return{reason:`brandMismatch`}}let o=vt.exec(t)?.[1]?.toLowerCase();if(o){let e=bt(o);if(e!==i&&!i.endsWith(`.${e}`))return{reason:`textMismatch`}}return null}var wt=`/* The selection toolbar's shadow-UI styles. Imported with \`?raw\` by
   selection.ts (as SELECTION_STYLE) and injected into \`createShadowRootUi\` by
   content.ts, concatenated with PREVIEW_STYLE — same reason it must stay a
   string at runtime: shadow DOM does not inherit page styles. */
.tp-sel {
  position: fixed;
  z-index: 2147483646;
  display: none;
  align-items: center;
  gap: 2px;
  padding: 6px 8px;
  border-radius: 999px;
  background: #fff;
  border: 1px solid rgba(0, 0, 0, .08);
  box-shadow: 0 10px 32px rgba(0, 0, 0, .16), 0 2px 6px rgba(0, 0, 0, .08);
  font-family: system-ui, -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
}

.tp-sel.tp-show {
  display: flex;
}

.tp-sel button {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  border: 0;
  border-radius: 999px;
  padding: 6px 12px;
  background: transparent;
  font-size: 13px;
  line-height: 1.2;
  color: #1f2328;
  cursor: pointer;
  white-space: nowrap;
}

.tp-sel button svg {
  width: 15px;
  height: 15px;
  flex: 0 0 auto;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.tp-sel button:hover {
  background: color-mix(in srgb, var(--tp-accent, #4f6bf6) 12%, #fff);
  color: var(--tp-accent, #4f6bf6);
}

/* The preview option is inert until the selection reads as a link. */
.tp-sel button:disabled {
  color: #aab2bd;
  cursor: default;
}

.tp-sel button:disabled:hover {
  background: transparent;
  color: #aab2bd;
}

.tp-sel .tp-sel-div {
  width: 1px;
  height: 16px;
  margin: 0 3px;
  background: rgba(0, 0, 0, .12);
}

/* The tail pointing back at the selected text: a rotated square that inherits
   the bar's fill *and* border colour, so the dark theme needs no rule of its
   own. Only the two sides that face away from the bar carry a border — the
   other two would draw lines across the bar's interior. Its position along the
   edge comes from --tp-arrow-x, written by show(). */
.tp-sel::after {
  content: "";
  position: absolute;
  width: 10px;
  height: 10px;
  background: inherit;
  border: 0 solid;
  border-color: inherit;
  pointer-events: none;
}

.tp-sel.tp-arrow-down::after {
  bottom: -5px;
  left: calc(var(--tp-arrow-x, 50%) - 5px);
  transform: rotate(45deg);
  border-right-width: 1px;
  border-bottom-width: 1px;
}

.tp-sel.tp-arrow-up::after {
  top: -5px;
  left: calc(var(--tp-arrow-x, 50%) - 5px);
  transform: rotate(45deg);
  border-left-width: 1px;
  border-top-width: 1px;
}

:host([data-tp-theme='dark']) .tp-sel .tp-sel-div {
  background: #333941;
}

:host([data-tp-theme='dark']) .tp-sel {
  background: #1e2126;
  border-color: #333941;
  box-shadow: 0 10px 32px rgba(0, 0, 0, .5), 0 2px 6px rgba(0, 0, 0, .4);
}

:host([data-tp-theme='dark']) .tp-sel button {
  color: #e6e8eb;
}

:host([data-tp-theme='dark']) .tp-sel button:hover {
  background: color-mix(in srgb, var(--tp-accent, #4f6bf6) 24%, #1e2126);
}

:host([data-tp-theme='dark']) .tp-sel button:disabled {
  color: #5c646e;
}

:host([data-tp-theme='dark']) .tp-sel button:disabled:hover {
  background: transparent;
  color: #5c646e;
}`;function Tt(e){let t=(N.i18n.getUILanguage()||``).toLowerCase();return e.lang[t.startsWith(`zh`)?`zh`:`en`]}function Et(e,t){return e.url.replace(`%t`,encodeURIComponent(Tt(e))).replace(`%s`,encodeURIComponent(t))}function Dt(e,t,n){console.log(`[Prelook] selection system created`);let r=document.createElement(`div`);r.className=`tp-sel`,n.appendChild(r);let i=!1,a=null;function o(){let e=document.getSelection()?.toString()??``;if(!e.trim())return null;let t=e.replace(/[\u200B-\u200D\uFEFF]/g,``),n=t.match(/https?:\/\/[^\s<>'"`\])）】}]+/i),r=n?n[0]:t.trim();try{console.log(`selectedLink:`,r);let e=new URL(r);return e.protocol===`http:`||e.protocol===`https:`?e.href:null}catch{return null}}function s(){let e=$(t.getSettings());r.innerHTML=``;let n=K.find(t=>t.id===e.searchEngine);if(n){let e=document.createElement(`button`);e.innerHTML=`<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg><span></span>`,e.querySelector(`span`).textContent=t.i18n.t(`selection.engines`),e.title=n.label,e.addEventListener(`click`,()=>d(n.url)),r.appendChild(e)}let i=oe.find(t=>t.id===e.translateEngine);if(i){let e=t.i18n.t(`translate.${i.id}`),n=document.createElement(`button`);n.innerHTML=`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 8 6 6"/><path d="m4 14 6-6 2-3"/><path d="M2 5h12"/><path d="M7 2h1"/><path d="m22 22-5-10-5 10"/><path d="M14 18h6"/></svg><span></span>`,n.querySelector(`span`).textContent=t.i18n.t(`selection.translate`),n.title=`${t.i18n.t(`selection.translate`)} · ${e}`,n.addEventListener(`click`,()=>f(i)),r.appendChild(n)}let s=q.find(t=>t.id===e.aiEngine);if(s){r.appendChild(document.createElement(`i`)).className=`tp-sel-div`;let e=document.createElement(`button`);e.innerHTML=`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.5 13.8 9l5.5 1.8-5.5 1.8L12 18.1l-1.8-5.5L4.7 10.8 10.2 9Z"/><path d="M19 15.5l.9 2.6 2.6.9-2.6.9-.9 2.6-.9-2.6-2.6-.9 2.6-.9Z"/></svg><span></span>`,e.querySelector(`span`).textContent=t.i18n.t(`selection.ai`),e.title=s.url.includes(`%s`)?`${t.i18n.t(`selection.ai`)} · ${s.label}`:`${t.i18n.t(`selection.ai`)} · ${s.label} ${t.i18n.t(`selection.aiCopyHint`)}`,e.addEventListener(`click`,()=>d(s.url)),r.appendChild(e)}let c=e.detectLinks?o():null,l=document.createElement(`button`);l.innerHTML=`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 12S6.3 5.5 12 5.5 21.5 12 21.5 12 17.7 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="2.8"/></svg><span></span>`,l.querySelector(`span`).textContent=t.i18n.t(`selection.preview`),l.disabled=!c,l.title=c??t.i18n.t(`selection.previewHint`),c&&l.addEventListener(`click`,()=>{m(),t.openPreview(c,a)}),r.appendChild(l)}function c(e){if(navigator.clipboard?.writeText){navigator.clipboard.writeText(e).catch(()=>l(e));return}l(e)}function l(e){let t=document.createElement(`textarea`);t.value=e,t.setAttribute(`readonly`,``),t.style.cssText=`position:fixed;top:-1000px;left:-1000px;opacity:0`,document.body.appendChild(t),t.select();try{document.execCommand(`copy`)}catch{}t.remove()}function u(e){N.runtime.sendMessage({type:`prelook:openTab`,url:e,background:$(t.getSettings()).openInBackground})}function d(e){let n=document.getSelection(),i=n?.toString().trim(),a=r.getBoundingClientRect();if(m(),!i)return;n?.removeAllRanges();let o=e.includes(`%s`);o||(c(i),t.notify(`selection.aiCopied`,a.left+a.width/2,a.top)),u(o?e.replace(`%s`,encodeURIComponent(i)):e)}function f(e){let n=document.getSelection(),r=n?.toString().trim();if(m(),!r)return;n?.removeAllRanges();let i=Et(e,r);e.inline?t.openPreview(i,a,{translate:!0,inline:{text:r,to:Tt(e)}}):e.openIn===`tab`?u(i):t.openPreview(i,a,{translate:!0})}function p(e){a=e,s();let n=$(t.getSettings());r.style.setProperty(`--tp-accent`,n.themeColor),r.classList.add(`tp-show`),i=!0;let o=r.offsetWidth||200,c=r.offsetHeight||40,l=e.left+e.width/2-o/2,u=e.top-c-8,d=u<8;d&&(u=Math.min(e.bottom+8,innerHeight-c-8)),l=Math.min(Math.max(8,l),Math.max(8,innerWidth-o-8)),r.style.left=`${l}px`,r.style.top=`${u}px`;let f=Math.min(c/2+8,o/2),p=e.left+e.width/2-l;r.style.setProperty(`--tp-arrow-x`,`${Math.min(Math.max(p,f),o-f)}px`),r.classList.toggle(`tp-arrow-up`,d),r.classList.toggle(`tp-arrow-down`,!d)}function m(){r.classList.remove(`tp-show`),i=!1}function h(e){return!!(e instanceof Element?e:e?.parentElement)?.closest?.(`input, textarea, [contenteditable="true"], [contenteditable=""]`)}function g(e){let n=$(t.getSettings());if(!n.selectionSearch||!n.enabled||ge(n.disabledSites,location.hostname)){m();return}if(e.text.length<n.minSelectionChars||e.rangeCount===0){m();return}if(h(e.anchorNode)){m();return}let r=e.rect;if(!r||r.width===0&&r.height===0&&r.top===0){m();return}p(r)}let _=null,v=!1,y=null;function b(){let e=document.getSelection(),t=e?.toString().trim()??``,n=null;try{n=e&&e.rangeCount>0?e.getRangeAt(0).getBoundingClientRect():null,(!n||n.width===0&&n.height===0)&&e?.anchorNode&&(n=(e.anchorNode instanceof Element?e.anchorNode:e.anchorNode.parentElement)?.getBoundingClientRect?.()??n)}catch{n=null}return{text:t,anchorNode:e?.anchorNode??null,rangeCount:e?.rangeCount??0,rect:n}}function x(e){_&&clearTimeout(_),_=setTimeout(()=>{g(e)},30)}return e.addEventListener(document,`selectionchange`,()=>{x(b())}),e.addEventListener(document,`pointerdown`,()=>{v=!0,y=null}),e.addEventListener(document,`pointermove`,()=>{if(!v)return;let e=b();(!y||e.text.length>y.text.length)&&(y=e),x(y)}),e.addEventListener(document,`pointerup`,e=>{v=!1,!e.composedPath().includes(r)&&(x(y??b()),y=null)}),e.addEventListener(document,`mousedown`,e=>{i&&(e.composedPath().includes(r)||m())},{capture:!0}),e.addEventListener(window,`scroll`,()=>{i&&m()},{capture:!0,passive:!0}),e.addEventListener(document,`keydown`,e=>{e.key===`Escape`&&i&&m()}),r.addEventListener(`mouseover`,e=>e.stopPropagation()),{isVisible:()=>i,hide:m,applySettings:()=>{i&&s(),r.style.setProperty(`--tp-accent`,$(t.getSettings()).themeColor)}}}function Ot(e){let t;try{t=document.speculationRules}catch{t=void 0}let n=new Set,r=!1;function i(e){try{t?.addRules(e)}catch{}}function a(e){if(r)return;r=!0;let t={source:`heuristics`,eagerness:e===`prerender`?`conservative`:`moderate`};i(e===`prerender`?{prerender:[t]}:{prefetch:[t]})}function o(r){let o=e.getSettings().speculationMode;if(!t||o===`off`||(a(o),n.has(r)))return;n.add(r);let s={urls:[r],eagerness:`immediate`};i(o===`prerender`?{prerender:[s]}:{prefetch:[s]})}return{onIntent:o}}function kt(){return typeof matchMedia==`function`&&matchMedia(`(prefers-color-scheme: dark)`).matches}function At(e){return e===`light`||e===`dark`?e:kt()?`dark`:`light`}function jt(e,t){let n=()=>t(At(e()));if(n(),typeof matchMedia!=`function`)return()=>{};let r=matchMedia(`(prefers-color-scheme: dark)`),i=()=>{e()===`system`&&n()};return r.addEventListener(`change`,i),()=>r.removeEventListener(`change`,i)}var Mt=new Set(`gclid,gclsrc,dclid,gbraid,wbraid,gad_source,fbclid,msclkid,twclid,ttclid,yclid,li_fat_id,igshid,igsh,mc_cid,mc_eid,mkt_tok,_hsenc,_hsmi,vero_id,vero_conv,wickedid,oly_anon_id,oly_enc_id,s_cid,sc_cid,elqTrackId,elqTrack,s_kwcid,trk,trkCampaign,WT.mc_id,wt_mc,_openstat,at_medium,at_campaign,_ga,_gl,_gac,hsCtaTracking`.split(`,`)),Nt=[`utm_`,`pk_`,`mtm_`,`hsa_`,`oly_`,`vero_`,`sc_campaign`],Pt=[{host:/^(www\.)?google\.[a-z.]{2,}$/,path:/^\/url$/,params:[`q`,`url`]},{host:/^(l|lm)\.facebook\.com$/,path:/^\/l\.php$/,params:[`u`]},{host:/^l\.instagram\.com$/,path:/^\/$/,params:[`u`]},{host:/^(www\.)?out\.reddit\.com$/,path:/^\/$/,params:[`url`]},{host:/^link\.zhihu\.com$/,path:/^\/$/,params:[`target`]},{host:/^(www\.)?youtube\.com$/,path:/^\/redirect$/,params:[`q`]},{host:/^steamcommunity\.com$/,path:/^\/linkfilter\/$/,params:[`url`]},{host:/^(www\.)?duckduckgo\.com$/,path:/^\/l\/$/,params:[`uddg`]}];function Ft(e){let t=e.toLowerCase();return Mt.has(e)||Mt.has(t)?!0:Nt.some(e=>t.startsWith(e))}function It(e){return e.protocol===`http:`||e.protocol===`https:`}function Lt(e){for(let t of Pt)if(t.host.test(e.hostname)&&t.path.test(e.pathname))for(let n of t.params){let t=e.searchParams.get(n);if(t)try{let e=new URL(t);if(It(e))return e.href}catch{}}return null}function Rt(e){let t=e;for(let e=0;e<3;e++){let e;try{e=new URL(t)}catch{return t}if(!It(e))return t;let n=Lt(e);if(!n||n===t)break;t=n}let n;try{n=new URL(t)}catch{return t}if(!It(n)||!n.search)return t;let r=new URLSearchParams,i=!1;for(let[e,t]of n.searchParams){if(Ft(e)){i=!0;continue}r.append(e,t)}if(!i)return t;let a=r.toString();return`${n.origin}${n.pathname}${a?`?${a}`:``}${n.hash}`}var zt=12;function Bt(e,t,n,r){return{url:t,pointer:{x:n.clientX,y:n.clientY},risk:r?Vt(t,e.textContent??``):void 0}}function Vt(e,t){return Ct(e,t)?.reason}function Ht(e){try{return/\.(jpe?g|png|gif|webp|svg|bmp|ico|avif)$/i.test(new URL(e).pathname)}catch{return!1}}function Ut(e){let t=e;return t?.closest?t.closest(`input, textarea, select, button`)?!0:t.isContentEditable===!0:!1}var Wt=l({matches:[`<all_urls>`],runAt:`document_idle`,main(e){let t={...X},n=_e,r=null,i=null,a=null,o=null,s=null,c=null,l=V();function u(){return n.level===`off`?t:{...t,speculationMode:`off`}}let d=Ot({getSettings:u});function f(){return $(t).highlightLinks&&n.level!==`max`}function p(){o?.toggleAttribute(`data-tp-motion`,n.reduceMotion),n.reduceMotion&&r?.cancelProgress(),r?.applyPower()}function m(){return $(t).maxWindows}function h(){return a||(a=(async()=>{(await L(e,{name:`prelook-ui`,position:`inline`,append:`last`,css:ut+`
`+wt,onMount(a,u){o=u.host,s?.(),s=jt(()=>t.theme,e=>o?.setAttribute(`data-tp-theme`,e)),c?.(),c=be(()=>t,e=>{n=e,p()}),r=dt({getSettings:()=>t,getMaxWindows:m,getPower:()=>n,i18n:l},u),i=Dt(e,{getSettings:()=>t,i18n:l,openPreview:(e,t,n)=>r?.open({...j(e,t),translate:n?.translate===!0,inlineTranslate:n?.inline}),notify:(e,t,n)=>r?.notice(e,t,n)},u)}})).mount()})(),a)}function g(e){let n=e.target;if(!n?.closest)return null;let r=document.querySelector(`prelook-ui`);if(r&&r.contains(n))return null;let i=n.closest(`a[href]`);if(!i||i.download)return null;let a=i.href;if(!/^https?:/i.test(a))return null;try{let e=new URL(a);if(e.hash&&e.origin===location.origin&&e.pathname===location.pathname)return null}catch{return null}return t.skipImages&&Ht(a)||ge(t.disabledSites,location.hostname)?null:{anchor:i,url:$(t).stripTracking?Rt(a):a}}let _=null,v=null,y=null;function b(){_&&(clearTimeout(_),_=null,r?.cancelProgress()),v=null}function x(e){return t.triggerMode===`altHover`?e.altKey:t.triggerMode===`hover`}function S(e){if(r?.keep(e.url),v===e.url)return;b(),v=e.url;let n=Bt(e.anchor,e.url,{clientX:e.x,clientY:e.y},$(t).warnDangerous),a=$(t).hoverDelayMs;_=setTimeout(()=>{_=null,v=null,r?.cancelProgress(),h().then(()=>{i?.isVisible()||r?.open(n)})},a),h().then(()=>{_&&v===e.url&&r?.startProgress(e.x,e.y,a)})}e.addEventListener(document,`pointerover`,e=>{let n=e,i=g(n);y=i&&t.enabled?{anchor:i.anchor,url:i.url,x:n.clientX,y:n.clientY}:null,i&&t.enabled&&d.onIntent(i.url),i&&t.enabled&&f()?h().then(()=>r?.highlightLink(i.anchor)):r?.highlightLink(null),y&&(x(n)||v===y.url)?S(y):(b(),n.composedPath().some(e=>e instanceof HTMLElement&&e.tagName===`PRELOOK-UI`)||(y&&t.triggerMode===`hoverSpace`?r?.keep(y.url):r?.releaseExcept(null)))}),e.addEventListener(document,`keydown`,e=>{let n=e;if(!t.enabled||!y)return;let r=t.triggerMode;if(r===`altHover`){if(n.key!==`Alt`||n.repeat||v)return;S(y);return}r===`hoverSpace`&&n.key===` `&&(Ut(n.target)||(n.preventDefault(),!(n.repeat||v)&&S(y)))}),e.addEventListener(document,`keyup`,e=>{let n=e;t.triggerMode===`altHover`&&n.key===`Alt`&&b()}),e.addEventListener(window,`pointerdown`,e=>{let n=e;t.enabled&&$(t).closeOnOutsideClick&&(n.composedPath().some(e=>e instanceof HTMLElement&&e.tagName===`PRELOOK-UI`)||r?.dismissUnpinned())},{capture:!0}),e.addEventListener(document,`pointerout`,e=>{let t=e;g(t)&&!t.relatedTarget&&(y=null,b(),r?.highlightLink(null))}),e.addEventListener(document,`mousedown`,e=>{let n=e;if(!t.enabled)return;let r=g(n);r&&d.onIntent(r.url)});let C=null,w=null,T=0,E=null,D=null;function O(){T++,D=null,C&&=(clearTimeout(C),null),w=null,r?.cancelProgress()}e.addEventListener(document,`pointerdown`,e=>{let n=e;O();let i=t.triggerMode;if(!t.enabled||i!==`longPress`&&i!==`drag`||n.button!==0||n.isPrimary===!1)return;let a=g(n);if(!a)return;let o=Bt(a.anchor,a.url,n,$(t).warnDangerous);if(i===`drag`){D={x:n.clientX,y:n.clientY,info:o};return}let s=$(t).longPressMs,{clientX:c,clientY:l}=n;w={x:c,y:l};let u=++T;C=setTimeout(()=>{C=null,w=null,h().then(()=>{u===T&&(r?.cancelProgress(),E=a.url,r?.open(o),r?.keep(a.url))})},s),h().then(()=>{u===T&&C&&r?.startProgress(c,l,s)})}),e.addEventListener(document,`pointerup`,()=>O()),e.addEventListener(document,`pointercancel`,()=>O()),e.addEventListener(document,`pointermove`,e=>{let t=e;if(D){if(Math.hypot(t.clientX-D.x,t.clientY-D.y)>zt){let{info:e}=D;D=null,E=e.url,h().then(()=>{r?.open(e),r?.keep(e.url)})}return}C&&w&&Math.hypot(t.clientX-w.x,t.clientY-w.y)>zt&&O()}),e.addEventListener(document,`dragstart`,e=>{t.enabled&&t.triggerMode===`drag`&&e.target?.closest?.(`a[href]`)&&e.preventDefault()});let k=null,A=!1;e.addEventListener(window,`pointerdown`,e=>{let n=e;if(k=null,A=!1,!t.enabled||t.triggerMode!==`altClick`||!n.altKey||n.button!==0||n.isPrimary===!1)return;let r=g(n);r&&(n.preventDefault(),A=!0,k={x:n.clientX,y:n.clientY,info:Bt(r.anchor,r.url,n,$(t).warnDangerous)})},{capture:!0}),e.addEventListener(window,`pointerup`,e=>{let t=k;if(k=null,!t)return;let n=e;Math.hypot(n.clientX-t.x,n.clientY-t.y)>zt||h().then(()=>{i?.hide(),r?.open(t.info)})},{capture:!0}),e.addEventListener(document,`pointercancel`,()=>{k=null,A=!1}),e.addEventListener(window,`click`,e=>{if(E){E=null,e.preventDefault(),e.stopPropagation();return}let n=e;if(!t.enabled||n.button!==0)return;let a=t.triggerMode,o=n.ctrlKey||n.metaKey||n.shiftKey;if(A){A=!1,a===`altClick`&&n.altKey&&!o&&(n.preventDefault(),n.stopPropagation());return}if(!(a===`click`&&!n.altKey&&!o||a===`altClick`&&n.altKey&&!o)||i?.isVisible())return;let s=g(n);if(!s)return;n.preventDefault(),n.stopPropagation();let c=Bt(s.anchor,s.url,n,$(t).warnDangerous);h().then(()=>r?.open(c))},{capture:!0});function j(e,n){let r=$(t),i=r.stripTracking?Rt(e):e,a=[...document.querySelectorAll(`a[href]`)].find(t=>t.href===e||t.href===i),o=r.warnDangerous?Vt(i,a?.textContent??``):void 0,s=n??a?.getBoundingClientRect();return s?{url:i,pointer:{x:s.left+s.width/2,y:s.top+s.height/2},risk:o}:{url:i,pointer:{x:Math.round(innerWidth/2),y:Math.round(innerHeight/2)},risk:o}}N.runtime.onMessage.addListener(e=>{if(typeof e!=`object`||!e)return;let t=e;if(t.type!==`prelook:preview`)return;let n=String(t.url??``);if(!/^https?:/i.test(n))return;let a=j(n);h().then(()=>{i?.hide(),r?.open({...a,sidebar:t.sidebar===!0})})}),Z.getValue().then(e=>{t=$({...X,...e}),t.enabled&&h()}),e.onInvalidated(()=>{s?.(),c?.(),r?.destroy()}),Z.watch(e=>{e&&(t=$({...X,...e}),s?.(),s=jt(()=>t.theme,e=>o?.setAttribute(`data-tp-theme`,e)),c?.(),c=be(()=>t,e=>{n=e,p()}),r?.applySettings($(t)),i?.applySettings($(t)))})}}),Gt=class e extends Event{static EVENT_NAME=Kt(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function Kt(e){return`${N?.runtime?.id}:content:${e}`}var qt=typeof globalThis.navigation?.addEventListener==`function`;function Jt(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),qt?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new Gt(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new Gt(e,t)),t=e)},1e3))}}}var Yt=class e{static SCRIPT_STARTED_MESSAGE_TYPE=Kt(`wxt:content-script-started`);id;abortController;locationWatcher=Jt(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return N.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?Kt(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),u.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}};function Xt(e){return e}var Zt=o(((e,t)=>{(function(n,r){"use strict";var i=`1.0.41`,a=``,o=`function`,s=`undefined`,c=`object`,l=`string`,u=`major`,d=`model`,f=`name`,p=`type`,m=`vendor`,h=`version`,g=`architecture`,_=`console`,v=`mobile`,y=`tablet`,b=`smarttv`,x=`wearable`,S=`embedded`,C=`Amazon`,w=`Apple`,T=`ASUS`,E=`BlackBerry`,D=`Browser`,O=`Chrome`,k=`Edge`,A=`Firefox`,j=`Google`,ee=`Honor`,M=`Huawei`,N=`Lenovo`,P=`LG`,F=`Microsoft`,I=`Motorola`,L=`Nvidia`,R=`OnePlus`,z=`Opera`,B=`OPPO`,V=`Samsung`,H=`Sharp`,U=`Sony`,W=`Xiaomi`,G=`Zebra`,te=`Facebook`,ne=`Chromium OS`,re=`Mac OS`,ie=` Browser`,ae=function(e,t){var n={};for(var r in e)n[r]=t[r]&&t[r].length%2==0?t[r].concat(e[r]):e[r];return n},K=function(e){for(var t={},n=0;n<e.length;n++)t[e[n].toUpperCase()]=e[n];return t},oe=function(e,t){return typeof e==l&&q(t).indexOf(q(e))!==-1},q=function(e){return e.toLowerCase()},se=function(e){return typeof e==l?e.replace(/[^\d\.]/g,a).split(`.`)[0]:r},ce=function(e,t){if(typeof e==l)return e=e.replace(/^\s\s*/,a),typeof t===s?e:e.substring(0,500)},J=function(e,t){for(var n=0,i,a,s,l,u,d;n<t.length&&!u;){var f=t[n],p=t[n+1];for(i=a=0;i<f.length&&!u&&f[i];)if(u=f[i++].exec(e),u)for(s=0;s<p.length;s++)d=u[++a],l=p[s],typeof l==c&&l.length>0?l.length===2?typeof l[1]==o?this[l[0]]=l[1].call(this,d):this[l[0]]=l[1]:l.length===3?typeof l[1]===o&&!(l[1].exec&&l[1].test)?this[l[0]]=d?l[1].call(this,d,l[2]):r:this[l[0]]=d?d.replace(l[1],l[2]):r:l.length===4&&(this[l[0]]=d?l[3].call(this,d.replace(l[1],l[2])):r):this[l]=d||r;n+=2}},Y=function(e,t){for(var n in t)if(typeof t[n]==c&&t[n].length>0){for(var i=0;i<t[n].length;i++)if(oe(t[n][i],e))return n===`?`?r:n}else if(oe(t[n],e))return n===`?`?r:n;return t.hasOwnProperty(`*`)?t[`*`]:e},le={"1.0":`/8`,"1.2":`/1`,"1.3":`/3`,"2.0":`/412`,"2.0.2":`/416`,"2.0.3":`/417`,"2.0.4":`/419`,"?":`/`},ue={ME:`4.90`,"NT 3.11":`NT3.51`,"NT 4.0":`NT4.0`,2e3:`NT 5.0`,XP:[`NT 5.1`,`NT 5.2`],Vista:`NT 6.0`,7:`NT 6.1`,8:`NT 6.2`,"8.1":`NT 6.3`,10:[`NT 6.4`,`NT 10.0`],RT:`ARM`},X={browser:[[/\b(?:crmo|crios)\/([\w\.]+)/i],[h,[f,`Chrome`]],[/edg(?:e|ios|a)?\/([\w\.]+)/i],[h,[f,`Edge`]],[/(opera mini)\/([-\w\.]+)/i,/(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i,/(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i],[f,h],[/opios[\/ ]+([\w\.]+)/i],[h,[f,z+` Mini`]],[/\bop(?:rg)?x\/([\w\.]+)/i],[h,[f,z+` GX`]],[/\bopr\/([\w\.]+)/i],[h,[f,z]],[/\bb[ai]*d(?:uhd|[ub]*[aekoprswx]{5,6})[\/ ]?([\w\.]+)/i],[h,[f,`Baidu`]],[/\b(?:mxbrowser|mxios|myie2)\/?([-\w\.]*)\b/i],[h,[f,`Maxthon`]],[/(kindle)\/([\w\.]+)/i,/(lunascape|maxthon|netfront|jasmine|blazer|sleipnir)[\/ ]?([\w\.]*)/i,/(avant|iemobile|slim(?:browser|boat|jet))[\/ ]?([\d\.]*)/i,/(?:ms|\()(ie) ([\w\.]+)/i,/(flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi|iridium|phantomjs|bowser|qupzilla|falkon|rekonq|puffin|brave|whale(?!.+naver)|qqbrowserlite|duckduckgo|klar|helio|(?=comodo_)?dragon)\/([-\w\.]+)/i,/(heytap|ovi|115)browser\/([\d\.]+)/i,/(weibo)__([\d\.]+)/i],[f,h],[/quark(?:pc)?\/([-\w\.]+)/i],[h,[f,`Quark`]],[/\bddg\/([\w\.]+)/i],[h,[f,`DuckDuckGo`]],[/(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i],[h,[f,`UC`+D]],[/microm.+\bqbcore\/([\w\.]+)/i,/\bqbcore\/([\w\.]+).+microm/i,/micromessenger\/([\w\.]+)/i],[h,[f,`WeChat`]],[/konqueror\/([\w\.]+)/i],[h,[f,`Konqueror`]],[/trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i],[h,[f,`IE`]],[/ya(?:search)?browser\/([\w\.]+)/i],[h,[f,`Yandex`]],[/slbrowser\/([\w\.]+)/i],[h,[f,`Smart Lenovo `+D]],[/(avast|avg)\/([\w\.]+)/i],[[f,/(.+)/,`$1 Secure `+D],h],[/\bfocus\/([\w\.]+)/i],[h,[f,A+` Focus`]],[/\bopt\/([\w\.]+)/i],[h,[f,z+` Touch`]],[/coc_coc\w+\/([\w\.]+)/i],[h,[f,`Coc Coc`]],[/dolfin\/([\w\.]+)/i],[h,[f,`Dolphin`]],[/coast\/([\w\.]+)/i],[h,[f,z+` Coast`]],[/miuibrowser\/([\w\.]+)/i],[h,[f,`MIUI`+ie]],[/fxios\/([\w\.-]+)/i],[h,[f,A]],[/\bqihoobrowser\/?([\w\.]*)/i],[h,[f,`360`]],[/\b(qq)\/([\w\.]+)/i],[[f,/(.+)/,`$1Browser`],h],[/(oculus|sailfish|huawei|vivo|pico)browser\/([\w\.]+)/i],[[f,/(.+)/,`$1`+ie],h],[/samsungbrowser\/([\w\.]+)/i],[h,[f,V+` Internet`]],[/metasr[\/ ]?([\d\.]+)/i],[h,[f,`Sogou Explorer`]],[/(sogou)mo\w+\/([\d\.]+)/i],[[f,`Sogou Mobile`],h],[/(electron)\/([\w\.]+) safari/i,/(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i,/m?(qqbrowser|2345(?=browser|chrome|explorer))\w*[\/ ]?v?([\w\.]+)/i],[f,h],[/(lbbrowser|rekonq)/i,/\[(linkedin)app\]/i],[f],[/ome\/([\w\.]+) \w* ?(iron) saf/i,/ome\/([\w\.]+).+qihu (360)[es]e/i],[h,f],[/((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i],[[f,te],h],[/(Klarna)\/([\w\.]+)/i,/(kakao(?:talk|story))[\/ ]([\w\.]+)/i,/(naver)\(.*?(\d+\.[\w\.]+).*\)/i,/(daum)apps[\/ ]([\w\.]+)/i,/safari (line)\/([\w\.]+)/i,/\b(line)\/([\w\.]+)\/iab/i,/(alipay)client\/([\w\.]+)/i,/(twitter)(?:and| f.+e\/([\w\.]+))/i,/(chromium|instagram|snapchat)[\/ ]([-\w\.]+)/i],[f,h],[/\bgsa\/([\w\.]+) .*safari\//i],[h,[f,`GSA`]],[/musical_ly(?:.+app_?version\/|_)([\w\.]+)/i],[h,[f,`TikTok`]],[/headlesschrome(?:\/([\w\.]+)| )/i],[h,[f,O+` Headless`]],[/ wv\).+(chrome)\/([\w\.]+)/i],[[f,O+` WebView`],h],[/droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i],[h,[f,`Android `+D]],[/(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i],[f,h],[/version\/([\w\.\,]+) .*mobile\/\w+ (safari)/i],[h,[f,`Mobile Safari`]],[/version\/([\w(\.|\,)]+) .*(mobile ?safari|safari)/i],[h,f],[/webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i],[f,[h,Y,le]],[/(webkit|khtml)\/([\w\.]+)/i],[f,h],[/(navigator|netscape\d?)\/([-\w\.]+)/i],[[f,`Netscape`],h],[/(wolvic|librewolf)\/([\w\.]+)/i],[f,h],[/mobile vr; rv:([\w\.]+)\).+firefox/i],[h,[f,A+` Reality`]],[/ekiohf.+(flow)\/([\w\.]+)/i,/(swiftfox)/i,/(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror)[\/ ]?([\w\.\+]+)/i,/(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i,/(firefox)\/([\w\.]+)/i,/(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i,/(amaya|dillo|doris|icab|ladybird|lynx|mosaic|netsurf|obigo|polaris|w3m|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i,/\b(links) \(([\w\.]+)/i],[f,[h,/_/g,`.`]],[/(cobalt)\/([\w\.]+)/i],[f,[h,/master.|lts./,``]]],cpu:[[/\b((amd|x|x86[-_]?|wow|win)64)\b/i],[[g,`amd64`]],[/(ia32(?=;))/i,/\b((i[346]|x)86)(pc)?\b/i],[[g,`ia32`]],[/\b(aarch64|arm(v?[89]e?l?|_?64))\b/i],[[g,`arm64`]],[/\b(arm(v[67])?ht?n?[fl]p?)\b/i],[[g,`armhf`]],[/( (ce|mobile); ppc;|\/[\w\.]+arm\b)/i],[[g,`arm`]],[/((ppc|powerpc)(64)?)( mac|;|\))/i],[[g,/ower/,a,q]],[/ sun4\w[;\)]/i],[[g,`sparc`]],[/\b(avr32|ia64(?=;)|68k(?=\))|\barm(?=v([1-7]|[5-7]1)l?|;|eabi)|(irix|mips|sparc)(64)?\b|pa-risc)/i],[[g,q]]],device:[[/\b(sch-i[89]0\d|shw-m380s|sm-[ptx]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i],[d,[m,V],[p,y]],[/\b((?:s[cgp]h|gt|sm)-(?![lr])\w+|sc[g-]?[\d]+a?|galaxy nexus)/i,/samsung[- ]((?!sm-[lr])[-\w]+)/i,/sec-(sgh\w+)/i],[d,[m,V],[p,v]],[/(?:\/|\()(ip(?:hone|od)[\w, ]*)(?:\/|;)/i],[d,[m,w],[p,v]],[/\((ipad);[-\w\),; ]+apple/i,/applecoremedia\/[\w\.]+ \((ipad)/i,/\b(ipad)\d\d?,\d\d?[;\]].+ios/i],[d,[m,w],[p,y]],[/(macintosh);/i],[d,[m,w]],[/\b(sh-?[altvz]?\d\d[a-ekm]?)/i],[d,[m,H],[p,v]],[/\b((?:brt|eln|hey2?|gdi|jdn)-a?[lnw]09|(?:ag[rm]3?|jdn2|kob2)-a?[lw]0[09]hn)(?: bui|\)|;)/i],[d,[m,ee],[p,y]],[/honor([-\w ]+)[;\)]/i],[d,[m,ee],[p,v]],[/\b((?:ag[rs][2356]?k?|bah[234]?|bg[2o]|bt[kv]|cmr|cpn|db[ry]2?|jdn2|got|kob2?k?|mon|pce|scm|sht?|[tw]gr|vrd)-[ad]?[lw][0125][09]b?|605hw|bg2-u03|(?:gem|fdr|m2|ple|t1)-[7a]0[1-4][lu]|t1-a2[13][lw]|mediapad[\w\. ]*(?= bui|\)))\b(?!.+d\/s)/i],[d,[m,M],[p,y]],[/(?:huawei)([-\w ]+)[;\)]/i,/\b(nexus 6p|\w{2,4}e?-[atu]?[ln][\dx][012359c][adn]?)\b(?!.+d\/s)/i],[d,[m,M],[p,v]],[/oid[^\)]+; (2[\dbc]{4}(182|283|rp\w{2})[cgl]|m2105k81a?c)(?: bui|\))/i,/\b((?:red)?mi[-_ ]?pad[\w- ]*)(?: bui|\))/i],[[d,/_/g,` `],[m,W],[p,y]],[/\b(poco[\w ]+|m2\d{3}j\d\d[a-z]{2})(?: bui|\))/i,/\b; (\w+) build\/hm\1/i,/\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i,/\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i,/oid[^\)]+; (m?[12][0-389][01]\w{3,6}[c-y])( bui|; wv|\))/i,/\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max|cc)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite|pro)?)(?: bui|\))/i,/ ([\w ]+) miui\/v?\d/i],[[d,/_/g,` `],[m,W],[p,v]],[/; (\w+) bui.+ oppo/i,/\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i],[d,[m,B],[p,v]],[/\b(opd2(\d{3}a?))(?: bui|\))/i],[d,[m,Y,{OnePlus:[`304`,`403`,`203`],"*":B}],[p,y]],[/vivo (\w+)(?: bui|\))/i,/\b(v[12]\d{3}\w?[at])(?: bui|;)/i],[d,[m,`Vivo`],[p,v]],[/\b(rmx[1-3]\d{3})(?: bui|;|\))/i],[d,[m,`Realme`],[p,v]],[/\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i,/\bmot(?:orola)?[- ](\w*)/i,/((?:moto(?! 360)[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i],[d,[m,I],[p,v]],[/\b(mz60\d|xoom[2 ]{0,2}) build\//i],[d,[m,I],[p,y]],[/((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i],[d,[m,P],[p,y]],[/(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i,/\blg[-e;\/ ]+((?!browser|netcast|android tv|watch)\w+)/i,/\blg-?([\d\w]+) bui/i],[d,[m,P],[p,v]],[/(ideatab[-\w ]+|602lv|d-42a|a101lv|a2109a|a3500-hv|s[56]000|pb-6505[my]|tb-?x?\d{3,4}(?:f[cu]|xu|[av])|yt\d?-[jx]?\d+[lfmx])( bui|;|\)|\/)/i,/lenovo ?(b[68]0[08]0-?[hf]?|tab(?:[\w- ]+?)|tb[\w-]{6,7})( bui|;|\)|\/)/i],[d,[m,N],[p,y]],[/(nokia) (t[12][01])/i],[m,d,[p,y]],[/(?:maemo|nokia).*(n900|lumia \d+|rm-\d+)/i,/nokia[-_ ]?(([-\w\. ]*))/i],[[d,/_/g,` `],[p,v],[m,`Nokia`]],[/(pixel (c|tablet))\b/i],[d,[m,j],[p,y]],[/droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i],[d,[m,j],[p,v]],[/droid.+; (a?\d[0-2]{2}so|[c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i],[d,[m,U],[p,v]],[/sony tablet [ps]/i,/\b(?:sony)?sgp\w+(?: bui|\))/i],[[d,`Xperia Tablet`],[m,U],[p,y]],[/ (kb2005|in20[12]5|be20[12][59])\b/i,/(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i],[d,[m,R],[p,v]],[/(alexa)webm/i,/(kf[a-z]{2}wi|aeo(?!bc)\w\w)( bui|\))/i,/(kf[a-z]+)( bui|\)).+silk\//i],[d,[m,C],[p,y]],[/((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i],[[d,/(.+)/g,`Fire Phone $1`],[m,C],[p,v]],[/(playbook);[-\w\),; ]+(rim)/i],[d,m,[p,y]],[/\b((?:bb[a-f]|st[hv])100-\d)/i,/\(bb10; (\w+)/i],[d,[m,E],[p,v]],[/(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i],[d,[m,T],[p,y]],[/ (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i],[d,[m,T],[p,v]],[/(nexus 9)/i],[d,[m,`HTC`],[p,y]],[/(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i,/(zte)[- ]([\w ]+?)(?: bui|\/|\))/i,/(alcatel|geeksphone|nexian|panasonic(?!(?:;|\.))|sony(?!-bra))[-_ ]?([-\w]*)/i],[m,[d,/_/g,` `],[p,v]],[/droid [\w\.]+; ((?:8[14]9[16]|9(?:0(?:48|60|8[01])|1(?:3[27]|66)|2(?:6[69]|9[56])|466))[gqswx])\w*(\)| bui)/i],[d,[m,`TCL`],[p,y]],[/(itel) ((\w+))/i],[[m,q],d,[p,Y,{tablet:[`p10001l`,`w7001`],"*":`mobile`}]],[/droid.+; ([ab][1-7]-?[0178a]\d\d?)/i],[d,[m,`Acer`],[p,y]],[/droid.+; (m[1-5] note) bui/i,/\bmz-([-\w]{2,})/i],[d,[m,`Meizu`],[p,v]],[/; ((?:power )?armor(?:[\w ]{0,8}))(?: bui|\))/i],[d,[m,`Ulefone`],[p,v]],[/; (energy ?\w+)(?: bui|\))/i,/; energizer ([\w ]+)(?: bui|\))/i],[d,[m,`Energizer`],[p,v]],[/; cat (b35);/i,/; (b15q?|s22 flip|s48c|s62 pro)(?: bui|\))/i],[d,[m,`Cat`],[p,v]],[/((?:new )?andromax[\w- ]+)(?: bui|\))/i],[d,[m,`Smartfren`],[p,v]],[/droid.+; (a(?:015|06[35]|142p?))/i],[d,[m,`Nothing`],[p,v]],[/; (x67 5g|tikeasy \w+|ac[1789]\d\w+)( b|\))/i,/archos ?(5|gamepad2?|([\w ]*[t1789]|hello) ?\d+[\w ]*)( b|\))/i],[d,[m,`Archos`],[p,y]],[/archos ([\w ]+)( b|\))/i,/; (ac[3-6]\d\w{2,8})( b|\))/i],[d,[m,`Archos`],[p,v]],[/(imo) (tab \w+)/i,/(infinix) (x1101b?)/i],[m,d,[p,y]],[/(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus(?! zenw)|dell|jolla|meizu|motorola|polytron|infinix|tecno|micromax|advan)[-_ ]?([-\w]*)/i,/; (hmd|imo) ([\w ]+?)(?: bui|\))/i,/(hp) ([\w ]+\w)/i,/(microsoft); (lumia[\w ]+)/i,/(lenovo)[-_ ]?([-\w ]+?)(?: bui|\)|\/)/i,/(oppo) ?([\w ]+) bui/i],[m,d,[p,v]],[/(kobo)\s(ereader|touch)/i,/(hp).+(touchpad(?!.+tablet)|tablet)/i,/(kindle)\/([\w\.]+)/i,/(nook)[\w ]+build\/(\w+)/i,/(dell) (strea[kpr\d ]*[\dko])/i,/(le[- ]+pan)[- ]+(\w{1,9}) bui/i,/(trinity)[- ]*(t\d{3}) bui/i,/(gigaset)[- ]+(q\w{1,9}) bui/i,/(vodafone) ([\w ]+)(?:\)| bui)/i],[m,d,[p,y]],[/(surface duo)/i],[d,[m,F],[p,y]],[/droid [\d\.]+; (fp\du?)(?: b|\))/i],[d,[m,`Fairphone`],[p,v]],[/(u304aa)/i],[d,[m,`AT&T`],[p,v]],[/\bsie-(\w*)/i],[d,[m,`Siemens`],[p,v]],[/\b(rct\w+) b/i],[d,[m,`RCA`],[p,y]],[/\b(venue[\d ]{2,7}) b/i],[d,[m,`Dell`],[p,y]],[/\b(q(?:mv|ta)\w+) b/i],[d,[m,`Verizon`],[p,y]],[/\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i],[d,[m,`Barnes & Noble`],[p,y]],[/\b(tm\d{3}\w+) b/i],[d,[m,`NuVision`],[p,y]],[/\b(k88) b/i],[d,[m,`ZTE`],[p,y]],[/\b(nx\d{3}j) b/i],[d,[m,`ZTE`],[p,v]],[/\b(gen\d{3}) b.+49h/i],[d,[m,`Swiss`],[p,v]],[/\b(zur\d{3}) b/i],[d,[m,`Swiss`],[p,y]],[/\b((zeki)?tb.*\b) b/i],[d,[m,`Zeki`],[p,y]],[/\b([yr]\d{2}) b/i,/\b(dragon[- ]+touch |dt)(\w{5}) b/i],[[m,`Dragon Touch`],d,[p,y]],[/\b(ns-?\w{0,9}) b/i],[d,[m,`Insignia`],[p,y]],[/\b((nxa|next)-?\w{0,9}) b/i],[d,[m,`NextBook`],[p,y]],[/\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i],[[m,`Voice`],d,[p,v]],[/\b(lvtel\-)?(v1[12]) b/i],[[m,`LvTel`],d,[p,v]],[/\b(ph-1) /i],[d,[m,`Essential`],[p,v]],[/\b(v(100md|700na|7011|917g).*\b) b/i],[d,[m,`Envizen`],[p,y]],[/\b(trio[-\w\. ]+) b/i],[d,[m,`MachSpeed`],[p,y]],[/\btu_(1491) b/i],[d,[m,`Rotor`],[p,y]],[/((?:tegranote|shield t(?!.+d tv))[\w- ]*?)(?: b|\))/i],[d,[m,L],[p,y]],[/(sprint) (\w+)/i],[m,d,[p,v]],[/(kin\.[onetw]{3})/i],[[d,/\./g,` `],[m,F],[p,v]],[/droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i],[d,[m,G],[p,y]],[/droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i],[d,[m,G],[p,v]],[/smart-tv.+(samsung)/i],[m,[p,b]],[/hbbtv.+maple;(\d+)/i],[[d,/^/,`SmartTV`],[m,V],[p,b]],[/(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i],[[m,P],[p,b]],[/(apple) ?tv/i],[m,[d,w+` TV`],[p,b]],[/crkey/i],[[d,O+`cast`],[m,j],[p,b]],[/droid.+aft(\w+)( bui|\))/i],[d,[m,C],[p,b]],[/(shield \w+ tv)/i],[d,[m,L],[p,b]],[/\(dtv[\);].+(aquos)/i,/(aquos-tv[\w ]+)\)/i],[d,[m,H],[p,b]],[/(bravia[\w ]+)( bui|\))/i],[d,[m,U],[p,b]],[/(mi(tv|box)-?\w+) bui/i],[d,[m,W],[p,b]],[/Hbbtv.*(technisat) (.*);/i],[m,d,[p,b]],[/\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i,/hbbtv\/\d+\.\d+\.\d+ +\([\w\+ ]*; *([\w\d][^;]*);([^;]*)/i],[[m,ce],[d,ce],[p,b]],[/droid.+; ([\w- ]+) (?:android tv|smart[- ]?tv)/i],[d,[p,b]],[/\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i],[[p,b]],[/(ouya)/i,/(nintendo) ([wids3utch]+)/i],[m,d,[p,_]],[/droid.+; (shield)( bui|\))/i],[d,[m,L],[p,_]],[/(playstation \w+)/i],[d,[m,U],[p,_]],[/\b(xbox(?: one)?(?!; xbox))[\); ]/i],[d,[m,F],[p,_]],[/\b(sm-[lr]\d\d[0156][fnuw]?s?|gear live)\b/i],[d,[m,V],[p,x]],[/((pebble))app/i,/(asus|google|lg|oppo) ((pixel |zen)?watch[\w ]*)( bui|\))/i],[m,d,[p,x]],[/(ow(?:19|20)?we?[1-3]{1,3})/i],[d,[m,B],[p,x]],[/(watch)(?: ?os[,\/]|\d,\d\/)[\d\.]+/i],[d,[m,w],[p,x]],[/(opwwe\d{3})/i],[d,[m,R],[p,x]],[/(moto 360)/i],[d,[m,I],[p,x]],[/(smartwatch 3)/i],[d,[m,U],[p,x]],[/(g watch r)/i],[d,[m,P],[p,x]],[/droid.+; (wt63?0{2,3})\)/i],[d,[m,G],[p,x]],[/droid.+; (glass) \d/i],[d,[m,j],[p,x]],[/(pico) (4|neo3(?: link|pro)?)/i],[m,d,[p,x]],[/; (quest( \d| pro)?)/i],[d,[m,te],[p,x]],[/(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i],[m,[p,S]],[/(aeobc)\b/i],[d,[m,C],[p,S]],[/(homepod).+mac os/i],[d,[m,w],[p,S]],[/windows iot/i],[[p,S]],[/droid .+?; ([^;]+?)(?: bui|; wv\)|\) applew).+? mobile safari/i],[d,[p,v]],[/droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i],[d,[p,y]],[/\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i],[[p,y]],[/(phone|mobile(?:[;\/]| [ \w\/\.]*safari)|pda(?=.+windows ce))/i],[[p,v]],[/droid .+?; ([\w\. -]+)( bui|\))/i],[d,[m,`Generic`]]],engine:[[/windows.+ edge\/([\w\.]+)/i],[h,[f,k+`HTML`]],[/(arkweb)\/([\w\.]+)/i],[f,h],[/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i],[h,[f,`Blink`]],[/(presto)\/([\w\.]+)/i,/(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna|servo)\/([\w\.]+)/i,/ekioh(flow)\/([\w\.]+)/i,/(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i,/(icab)[\/ ]([23]\.[\d\.]+)/i,/\b(libweb)/i],[f,h],[/ladybird\//i],[[f,`LibWeb`]],[/rv\:([\w\.]{1,9})\b.+(gecko)/i],[h,f]],os:[[/microsoft (windows) (vista|xp)/i],[f,h],[/(windows (?:phone(?: os)?|mobile|iot))[\/ ]?([\d\.\w ]*)/i],[f,[h,Y,ue]],[/windows nt 6\.2; (arm)/i,/windows[\/ ]([ntce\d\. ]+\w)(?!.+xbox)/i,/(?:win(?=3|9|n)|win 9x )([nt\d\.]+)/i],[[h,Y,ue],[f,`Windows`]],[/[adehimnop]{4,7}\b(?:.*os ([\w]+) like mac|; opera)/i,/(?:ios;fbsv\/|iphone.+ios[\/ ])([\d\.]+)/i,/cfnetwork\/.+darwin/i],[[h,/_/g,`.`],[f,`iOS`]],[/(mac os x) ?([\w\. ]*)/i,/(macintosh|mac_powerpc\b)(?!.+haiku)/i],[[f,re],[h,/_/g,`.`]],[/droid ([\w\.]+)\b.+(android[- ]x86|harmonyos)/i],[h,f],[/(ubuntu) ([\w\.]+) like android/i],[[f,/(.+)/,`$1 Touch`],h],[/(android|bada|blackberry|kaios|maemo|meego|openharmony|qnx|rim tablet os|sailfish|series40|symbian|tizen|webos)\w*[-\/; ]?([\d\.]*)/i],[f,h],[/\(bb(10);/i],[h,[f,E]],[/(?:symbian ?os|symbos|s60(?=;)|series ?60)[-\/ ]?([\w\.]*)/i],[h,[f,`Symbian`]],[/mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i],[h,[f,A+` OS`]],[/web0s;.+rt(tv)/i,/\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i],[h,[f,`webOS`]],[/watch(?: ?os[,\/]|\d,\d\/)([\d\.]+)/i],[h,[f,`watchOS`]],[/crkey\/([\d\.]+)/i],[h,[f,O+`cast`]],[/(cros) [\w]+(?:\)| ([\w\.]+)\b)/i],[[f,ne],h],[/panasonic;(viera)/i,/(netrange)mmh/i,/(nettv)\/(\d+\.[\w\.]+)/i,/(nintendo|playstation) ([wids345portablevuch]+)/i,/(xbox); +xbox ([^\);]+)/i,/\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i,/(mint)[\/\(\) ]?(\w*)/i,/(mageia|vectorlinux)[; ]/i,/([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i,/(hurd|linux)(?: arm\w*| x86\w*| ?)([\w\.]*)/i,/(gnu) ?([\w\.]*)/i,/\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i,/(haiku) (\w+)/i],[f,h],[/(sunos) ?([\w\.\d]*)/i],[[f,`Solaris`],h],[/((?:open)?solaris)[-\/ ]?([\w\.]*)/i,/(aix) ((\d)(?=\.|\)| )[\w\.])*/i,/\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux|serenityos)/i,/(unix) ?([\w\.]*)/i],[f,h]]},Z=function(e,t){if(typeof e==c&&(t=e,e=r),!(this instanceof Z))return new Z(e,t).getResult();var i=typeof n!==s&&n.navigator?n.navigator:r,_=e||(i&&i.userAgent?i.userAgent:a),b=i&&i.userAgentData?i.userAgentData:r,x=t?ae(X,t):X,S=i&&i.userAgent==_;return this.getBrowser=function(){var e={};return e[f]=r,e[h]=r,J.call(e,_,x.browser),e[u]=se(e[h]),S&&i&&i.brave&&typeof i.brave.isBrave==o&&(e[f]=`Brave`),e},this.getCPU=function(){var e={};return e[g]=r,J.call(e,_,x.cpu),e},this.getDevice=function(){var e={};return e[m]=r,e[d]=r,e[p]=r,J.call(e,_,x.device),S&&!e[p]&&b&&b.mobile&&(e[p]=v),S&&e[d]==`Macintosh`&&i&&typeof i.standalone!==s&&i.maxTouchPoints&&i.maxTouchPoints>2&&(e[d]=`iPad`,e[p]=y),e},this.getEngine=function(){var e={};return e[f]=r,e[h]=r,J.call(e,_,x.engine),e},this.getOS=function(){var e={};return e[f]=r,e[h]=r,J.call(e,_,x.os),S&&!e[f]&&b&&b.platform&&b.platform!=`Unknown`&&(e[f]=b.platform.replace(/chrome os/i,ne).replace(/macos/i,re)),e},this.getResult=function(){return{ua:this.getUA(),browser:this.getBrowser(),engine:this.getEngine(),os:this.getOS(),device:this.getDevice(),cpu:this.getCPU()}},this.getUA=function(){return _},this.setUA=function(e){return _=typeof e==l&&e.length>500?ce(e,500):e,this},this.setUA(_),this};Z.VERSION=i,Z.BROWSER=K([f,h,u]),Z.CPU=K([g]),Z.DEVICE=K([d,m,p,_,v,b,y,x,S]),Z.ENGINE=Z.OS=K([f,h]),typeof e===s?typeof define===o&&define.amd?define(function(){return Z}):typeof n!==s&&(n.UAParser=Z):(typeof t!==s&&t.exports&&(e=t.exports=Z),e.UAParser=Z);var Q=typeof n!==s&&(n.jQuery||n.Zepto);if(Q&&!Q.ua){var de=new Z;Q.ua=de.getResult(),Q.ua.get=function(){return de.getUA()},Q.ua.set=function(e){de.setUA(e);var t=de.getResult();for(var n in t)Q.ua[n]=t[n]}}})(typeof window==`object`?window:e)}))();function Qt(){return M?.runtime?.id?typeof ServiceWorkerGlobalScope<`u`&&self instanceof ServiceWorkerGlobalScope||typeof window<`u`&&typeof M.extension?.getBackgroundPage==`function`&&M.extension.getBackgroundPage()===window:!1}var $t;function en(){return $t??=Qt(),$t}var tn=`@wxt-dev/analytics`,nn=new Set([`A`,`BUTTON`,`INPUT`,`SELECT`,`TEXTAREA`]),rn=new Set([`button`,`link`,`checkbox`,`menuitem`,`tab`,`radio`]);function an(e){if(!M?.runtime?.id)throw Error(`Cannot use WXT analytics in contexts without access to the browser.runtime APIs`);return e??console.warn(`[@wxt-dev/analytics] Config not provided to createAnalytics. If you're using WXT, add the 'analytics' property to '<srcDir>/app.config.ts'.`),en()?on(e):sn()}function on(e){let t=e?.userId??cn(`wxt-analytics:user-id`),n=e?.userProperties??cn(`wxt-analytics:user-properties`,{}),r=e?.enabled??cn(`local:wxt-analytics:enabled`,!1),i=M.runtime.getPlatformInfo(),a=(0,Zt.UAParser)(),o=Promise.resolve(t.getValue()).then(async e=>{if(e!=null)return e;let n=globalThis.crypto.randomUUID();return await t.setValue?.(n),n}),s=n.getValue(),c=M.runtime.getManifest(),l=()=>({timestamp:Date.now(),sessionId:void 0,language:navigator.language,referrer:void 0,screen:void 0,url:location.href,title:void 0}),u=async t=>{let{arch:n,os:r}=await i;return{meta:t,user:{id:await o,properties:{version:e?.version??c.version_name??c.version,wxtMode:`production`,wxtBrowser:`chrome`,arch:n,os:r,browser:a.browser.name,browserVersion:a.browser.version,...await s}}}},d={identify:async(i,a={},c=l())=>{o=Promise.resolve(i),s=Promise.resolve(a),await Promise.all([t.setValue?.(i),n.setValue?.(a)]);let d=await u(c);e?.debug&&console.debug(`[@wxt-dev/analytics] identify`,d),await r.getValue()?await Promise.allSettled(f.map(e=>e.identify(d))):e?.debug&&console.debug(`[@wxt-dev/analytics] Analytics disabled, identify() not uploaded`)},page:async(t,n=l())=>{let i={...await u(n),page:{url:n?.url??globalThis.location?.href,location:t,title:n?.title??globalThis.document?.title}};e?.debug&&console.debug(`[@wxt-dev/analytics] page`,i),await r.getValue()?await Promise.allSettled(f.map(e=>e.page(i))):e?.debug&&console.debug(`[@wxt-dev/analytics] Analytics disabled, page() not uploaded`)},track:async(t,n,i=l())=>{let a={...await u(i),event:{name:t,properties:n}};e?.debug&&console.debug(`[@wxt-dev/analytics] track`,a),await r.getValue()?await Promise.allSettled(f.map(e=>e.track(a))):e?.debug&&console.debug(`[@wxt-dev/analytics] Analytics disabled, track() not uploaded`)},setEnabled:async e=>{await r.setValue?.(e)},autoTrack:()=>()=>{}},f=e?.providers?.map(t=>t(d,e))??[];return M.runtime.onConnect.addListener(e=>{e.name===tn&&e.onMessage.addListener(({fn:e,args:t})=>{d[e]?.(...t)})}),d}function sn(){let e=M.runtime.connect({name:tn}),t=Date.now(),n=()=>({sessionId:t,timestamp:Date.now(),language:navigator.language,referrer:document.referrer||void 0,screen:`${window.screen.width}x${window.screen.height}`,url:location.href,title:document.title||void 0}),r=t=>(...r)=>(e.postMessage({fn:t,args:[...r,n()]}),Promise.resolve()),i={identify:r(`identify`),page:r(`page`),track:r(`track`),setEnabled:r(`setEnabled`),autoTrack:e=>{let t=e=>{let t=e.target;t&&(nn.has(t.tagName)||rn.has(t.getAttribute(`role`)??``))&&i.track(`click`,{tagName:t.tagName?.toLowerCase(),id:t.id||void 0,className:t.className||void 0,textContent:t.textContent?.substring(0,50)||void 0,href:t.href})};return e.addEventListener(`click`,t,{capture:!0,passive:!0}),()=>{e.removeEventListener(`click`,t)}}};return i}function cn(e,t){return{getValue:async()=>(await M.storage.local.get(e))[e]??t,setValue:t=>M.storage.local.set({[e]:t})}}function ln(e){return t=>(n,r)=>e(n,r,t)}var un=100,dn=Xt({analytics:{providers:[ln((e,t,n)=>{let r=async(e,r,i)=>{let a=new URL(t.debug?`/debug/mp/collect`:`/mp/collect`,n.apiUrl??`https://www.google-analytics.com`);n.apiSecret&&a.searchParams.set(`api_secret`,n.apiSecret),n.measurementId&&a.searchParams.set(`measurement_id`,n.measurementId);let o={language:e.meta.language,screen:e.meta.screen,...e.user.properties},s=Object.fromEntries(Object.entries(o).map(([e,t])=>[e,t==null?void 0:{value:t}]));t.debug&&console.debug(`[@wxt-dev/analytics] Sending event to Google Analytics 4:`,{eventName:r,eventProperties:i}),await fetch(a.href,{method:`POST`,body:JSON.stringify({client_id:e.user.id,consent:{ad_user_data:`DENIED`,ad_personalization:`DENIED`},user_properties:s,user_agent:navigator.userAgent,events:[{name:r,params:{session_id:e.meta.sessionId,engagement_time_msec:un,...i}}]})})};return{identify:()=>Promise.resolve(),page:e=>r(e,`page_view`,{page_title:e.page.title,page_location:e.page.location}),track:e=>r(e,e.event.name,e.event.properties)}})({apiSecret:void 0,measurementId:`G-JM4BG6CP3W`})]}});function fn(){return dn}function pn(){return fn()}an(pn().analytics);var mn={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=Wt;return await e(new Yt(`content`,t))}catch(e){throw mn.error(`The content script "content" crashed on startup!`,e),e}})()})();